# PR19 quantity refusal — independent receiving patch

This patch is ready for the PR19 author's adoption. It has not been published or applied to an author checkout. The original value-admission work remains owned by that author.

## Exact source and change

The native baseline is `Jacob-Met/ledgerly` PR19 head `f67e2c4034804f657eccad38887f377f28011e98`, tree `ae425d9afb682b55138143780b461d1c61e9e820`. All five native inputs were checked against that full tree. It has no `AGENTS.md` or `CONTINUE.md`. The unmodified extractor blob is `100e581d3ef0d99555f49264859d01b535c6094f`, SHA-256 `4921f5df19cb35089afc8db3641cae9b8fbd089279dd84ef9555c10b759e2f16`.

`parse-qty-refusal.patch` wraps only the two `_dec` calls inside `parse_qty`. A refused numeric quantity or refused range lower bound now returns an unknown quantity and an explanatory parse reason. Both existing bullet and table consumers turn this into a field-level error, and existing Agent admission returns `needs_review` before any invoice-number or draft request. The patch does not change the finite/arithmetic bounds, amount validation, regexes, accepted quantity representations, money parsing, range interpretation or Agent/provider code.

Bytes outside `parse_qty` match the original source exactly. All other native inputs match the author head. `git apply --check` succeeds against the preserved native baseline.

## Independent qualification

The same stdlib-only receiver runs against both baseline and candidate under CPython 3.12.14. It contains ten test methods and 22 input/format subcases. The five ordinary control methods pass on the original source. Five regression methods produce ten original `ValueError` subcase errors, one per bullet/table form; those raw tracebacks are retained in `baseline.stderr`. The candidate passes all ten methods with no errors or skips.

The cases cover exact maximum `1000000`, fraction `1.25`, grouped fraction `1,234.50`, existing ordinary approximate/range warnings, and review at `1000001`. Regressions use the actual 29-digit `10000000000000000000000000000` quantity in plain, approximate, range-lower and approximate-range-lower forms, plus a valid first item followed by that unsupported second item. Each refusal is exercised through `RulesExtractor.extract`, its actual `to_dict`, direct `Agent.tool_create_invoice`, and `Agent.run` with the existing `RulePlanner`. Candidate refusals return field-level quantity review, allocate no invoice numbers or drafts, queue no pending actions, and make **zero `SandboxMock.requests`**. Valid controls preserve exact produced item values and existing pending-send approval; no send is performed.

Run the focused receiver explicitly; no development dependency installation is required:

```sh
python -B test_quantity_receiving.py --source-root /absolute/path/to/ledgerly/source
```

This receiver lives outside automatic project test collection because it requires an explicit source root. The author may adopt its cases into their normal test layout. `baseline-run.json` and `candidate-run.json` retain exact commands, test hashes, runtime and exit status. No broad native suite or browser suite was repeated for this two-call boundary repair.

## Ownership continuity

The reported defect is [root's PR19 finding](https://github.com/Jacob-Met/ledgerly/pull/19#issuecomment-6060078538). After the substantive preparation and native runs, the fresh PR read still showed head `f67e2c4034804f657eccad38887f377f28011e98` and only that finding comment. No owner correction was visible at that observation. `ownership-after-preparation.json` preserves the exact read. Root retains publication and author coordination; this packet does not transfer ownership or replace the published head.
