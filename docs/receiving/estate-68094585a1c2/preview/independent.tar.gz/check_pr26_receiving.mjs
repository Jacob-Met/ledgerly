import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {chromium, expect} from '/Users/me/longwater-author-tests-566d51f04b31/node_modules/playwright/test.mjs';
import {approvalListMarkup} from './source/web-demo/src/approval-preview.ts';

const root=path.dirname(fileURLToPath(import.meta.url));
const output=path.join(root,'evidence-v1');
fs.mkdirSync(output,{recursive:false});
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const git=b=>crypto.createHash('sha1').update(Buffer.from(`blob ${b.length}\0`)).update(b).digest('hex');
const read=p=>fs.readFileSync(path.join(root,p));
const fixtures=JSON.parse(read('fixtures/manifest.json'));
const sourcePins=JSON.parse(read('source-pins.json'));
const report={started_at:new Date().toISOString(),source_commit:sourcePins.commit,source_pins:sourcePins,
  runtime:{node:process.version},fixture_controls:[],public_controls:[],page_errors:[],off_origin:[],served:[],ok:false};
const record=()=>fs.writeFileSync(path.join(output,'receipt.json'),JSON.stringify(report,null,2)+'\n');
const check=(group,name,details={})=>{report[group].push({name,passed:true,...details});record();};
const immutable=value=>{if(value&&typeof value==='object'){Object.freeze(value);for(const x of Object.values(value))immutable(x);}return value;};
let browser;
try {
  for(const item of sourcePins.files)assert.equal(sha(read('source/'+item.path)),item.sha256,item.path);
  assert.equal(sha(read('fixtures/manifest.json')),'a07c52d68c24cd09ec9c7cfe9432831a7442209e0424aca8e1313790cf147446');
  const fixtureRows=fixtures.fixtures.map(item=>{const b=read('fixtures/'+item.path);assert.equal(sha(b),item.sha256,item.path);return {name:item.path,value:immutable(JSON.parse(b))};});
  browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
  report.runtime.chrome=browser.version();
  const fixtureContext=await browser.newContext({viewport:{width:390,height:844}});
  await fixtureContext.route('**/*',route=>{report.off_origin.push(route.request().url());return route.abort();});
  const fixturePage=await fixtureContext.newPage();
  fixturePage.on('pageerror',e=>report.page_errors.push(String(e)));
  const css=read('source/web-demo/src/style.css').toString()+'\n'+read('source/web-demo/src/approval-preview.css').toString();
  for(const {name,value} of fixtureRows){
    const before=JSON.stringify(value), queue=value.state.pending;
    const markup=approvalListMarkup(queue);
    assert.equal(JSON.stringify(value),before);
    await fixturePage.setContent('<!doctype html><meta name="viewport" content="width=device-width"><style>'+css+'</style><section id="approval-list" class="approval-list">'+markup+'</section>');
    await expect(fixturePage.locator('.approval-card')).toHaveCount(queue.length);
    for(const action of queue){
      const card=fixturePage.locator('[data-approval-id="'+action.id+'"]');
      await expect(card.locator('[data-approve]')).toHaveAttribute('data-approve',action.id);
      await expect(card.locator('[data-reject]')).toHaveAttribute('data-reject',action.id);
      if(action.kind==='send_invoice'){
        const invoice=action.payload.invoice;
        const rows=card.locator('tbody tr');await expect(rows).toHaveCount(invoice.items.length);
        for(let i=0;i<invoice.items.length;i++){
          const item=invoice.items[i],cells=rows.nth(i).locator('td');
          assert.equal(await cells.nth(0).textContent(),item.name);
          assert.equal(await cells.nth(1).textContent(),item.quantity+(item.unit_of_measure==='HOURS'?' hr':''));
          assert.equal(await cells.nth(2).textContent(),item.unit_amount.currency_code+' '+item.unit_amount.value);
          assert.equal(await cells.nth(0).evaluate(e=>getComputedStyle(e).whiteSpace),'pre-wrap');
        }
        assert.equal(await card.locator('[data-preview-invoice-note]').textContent(),invoice.detail.note);
        await expect(card).toContainText(invoice.primary_recipients[0].billing_info.email_address);
        await expect(card).toContainText(invoice.detail.currency_code+' '+action.payload.prepaid);
        if(invoice.detail.payment_term.term_type==='DUE_ON_RECEIPT'){
          await expect(card).toContainText('Due on receipt');assert.equal(await card.locator('dt').allTextContents().then(xs=>xs.includes('Due date')),false);
        }
      }else{
        assert.equal(await card.locator('[data-preview-reminder-note]').textContent(),action.payload.note);
        assert.equal(await card.locator('dd').textContent(),action.payload.subject);
        assert.equal(await card.locator('[data-preview-reminder-note]').evaluate(e=>getComputedStyle(e).whiteSpace),'pre-wrap');
      }
      assert.equal(await card.locator('img,svg,script,iframe').count(),0);
    }
    assert.equal(await fixturePage.evaluate(()=>window.__pendingLiteral),undefined);
    if(name==='jpy-original-amount-pending.json')await fixturePage.locator('#approval-list').screenshot({path:path.join(output,'fixture-jpy-phone.png')});
    check('fixture_controls','exact_native_payload_to_owner_DOM:'+name,{pending_ids:queue.map(x=>x.id),fixture_sha256:sha(Buffer.from(before))});
  }
  await fixtureContext.close();

  const origin='https://jacobmetoyer.com',base=origin+'/ledgerly/';
  const context=await browser.newContext({viewport:{width:390,height:844}});
  await context.route('**/*',route=>{
    const url=new URL(route.request().url());
    if(url.origin!==origin){report.off_origin.push(url.href);return route.abort();}
    return route.continue();
  });
  await context.addInitScript(()=>{
    window.__pr26Observation={sent:[],received:[]};const NativeWorker=window.Worker;
    window.Worker=class extends NativeWorker{
      constructor(url,options){super(url,options);this.addEventListener('message',e=>window.__pr26Observation.received.push(structuredClone(e.data)));}
      postMessage(message,...rest){window.__pr26Observation.sent.push(structuredClone(message));return super.postMessage(message,...rest);}
    };
  });
  const page=await context.newPage();page.setDefaultTimeout(15000);
  page.on('pageerror',e=>report.page_errors.push(String(e)));
  const responseTasks=[];
  context.on('response',response=>responseTasks.push((async()=>{
    const url=response.url();if(!url.startsWith(base))return;
    try{const b=await response.body();report.served.push({path:url.slice(base.length)||'index.html',url,status:response.status(),bytes:b.length,sha256:sha(b),git_blob:git(b)});}catch(e){report.served.push({url,error:String(e)});}
  })()));
  await page.goto(base,{waitUntil:'domcontentloaded',timeout:30000});
  report.public_url=page.url();
  await page.locator('#engine-start').click();
  await expect(page.locator('#engine-status')).toHaveText('PYTHON READY / OFFLINE',{timeout:60000});
  const idle=()=>expect(page.locator('#job-email')).toBeEnabled();
  const state=()=>page.evaluate(()=>window.__pr26Observation.received.filter(x=>x.data?.state).at(-1).data.state);
  const messages=()=>page.evaluate(()=>window.__pr26Observation.sent.length);
  const fixtureByName=name=>fixtureRows.find(x=>x.name===name).value;
  const currentCard=()=>page.locator('#approval-list .approval-card');
  async function action(selector){await page.locator(selector).click();await idle();}
  async function reviewedDraft(values){
    await page.locator('#job-email').fill(read('fixtures/07_partial_payment_deposit.txt').toString());
    await action('#analyze');
    await page.locator('#review-editor summary').click();
    for(const [id,value] of Object.entries(values)){
      const target=page.locator('#'+id);
      if(id.endsWith('-currency'))await target.selectOption(value);else await target.fill(value);
    }
    await page.locator('#review-confirm').check();await action('#review-check');
    await expect(page.locator('#draft')).toBeEnabled();await action('#draft');
    await expect(currentCard()).toHaveCount(1);return (await state()).pending[0];
  }
  await page.locator('#demo-date').fill('2026-10-08');await action('#advance-clock');
  const jpyFixture=fixtureByName('jpy-original-amount-pending.json').state.pending[0].payload;
  const jpy=await reviewedDraft({'review-client-name':'Fictional 日本語 Recipient','review-client-email':'review-recipient@example.test',
    'review-due-days':'30','review-amount-paid':'0','review-line-0-desc':'Localization review','review-line-0-qty':'1.00',
    'review-line-0-price':'1234','review-line-0-currency':'JPY','review-line-0-unit':'item'});
  assert.deepEqual(jpy.payload,jpyFixture);
  const cells=currentCard().locator('tbody td');
  assert.equal(await cells.nth(1).textContent(),'1.00');assert.equal(await cells.nth(2).textContent(),'JPY 1234');
  const prior=await state(),sentBefore=await messages();
  await currentCard().locator('summary').focus();await page.keyboard.press('Enter');await page.keyboard.press('Enter');
  assert.equal(await messages(),sentBefore);assert.deepEqual(await state(),prior);
  await currentCard().screenshot({path:path.join(output,'public-jpy-phone.png')});
  check('public_controls','delivered_JPY_original_queue_strings_and_local_keyboard_disclosure',{action_id:jpy.id,quantity:'1.00',unit_value:'1234'});
  await page.locator('#job-email').fill(read('fixtures/02_gbp_proofreading.txt').toString());await action('#analyze');
  assert.deepEqual((await state()).pending,[jpy]);assert.equal(await cells.nth(2).textContent(),'JPY 1234');
  await action('[data-reject="'+jpy.id+'"]');assert.equal((await state()).pending.length,0);
  check('public_controls','later_analysis_preserves_queued_JPY_then_explicit_reject_removes_only_it');
  page.once('dialog',dialog=>dialog.accept());await action('#reset-sandbox');
  await page.locator('#demo-date').fill('2026-10-08');await action('#advance-clock');
  const usd=await reviewedDraft({'review-client-name':'Review <img src=x onerror="window.__pendingLiteral=1">',
    'review-client-email':'review-recipient@example.test','review-due-days':'0','review-amount-paid':'1.20',
    'review-line-0-desc':'Scope <svg/onload=window.__pendingLiteral=2> & "quoted"',
    'review-line-0-qty':'2.50','review-line-0-price':'12.40','review-line-0-currency':'USD','review-line-0-unit':'hours'});
  assert.equal(usd.payload.invoice.items[0].quantity,'2.50');assert.equal(usd.payload.invoice.items[0].unit_amount.value,'12.40');
  assert.equal(usd.payload.prepaid,'1.20');assert.deepEqual(usd.payload.invoice.detail.payment_term,{term_type:'DUE_ON_RECEIPT'});
  assert.equal(await currentCard().locator('img,svg,script').count(),0);assert.equal(await page.evaluate(()=>window.__pendingLiteral),undefined);
  await action('[data-approve="'+usd.id+'"]');
  await page.locator('#demo-date').fill('2026-10-09');await action('#advance-clock');await action('#run-chase');
  const reminder=(await state()).pending[0], oldWords=reminder.payload.note;
  const oldFixture=fixtureByName('partial-payment-reminder-pending.json').state.pending[0].payload;
  assert.equal(reminder.payload.subject,oldFixture.subject);assert.equal(oldWords,oldFixture.note);
  assert.equal(await page.locator('[data-preview-reminder-note]').textContent(),oldWords);
  const selectionBefore=await messages();
  assert.equal(await page.locator('[data-preview-reminder-note]').evaluate(e=>{const range=document.createRange();range.selectNodeContents(e);const s=getSelection();s.removeAllRanges();s.addRange(range);return s.toString();}),oldWords);
  assert.equal(await messages(),selectionBefore);
  await page.locator('#approval-list').screenshot({path:path.join(output,'public-partial-reminder-phone.png')});
  await page.locator('#payment-amount').fill('1.00');await action('[data-pay="'+reminder.invoice_id+'"]');
  assert.deepEqual((await state()).pending,[]);await expect(page.locator('[data-preview-reminder-note]')).toHaveCount(0);
  assert.equal(await page.locator('[data-approve="'+reminder.id+'"]').count(),0);
  await action('#run-chase');const refreshed=(await state()).pending[0];assert.notEqual(refreshed.id,reminder.id);
  assert.equal(refreshed.payload.note,fixtureByName('reminder-after-explicit-redraft.json').state.pending[0].payload.note);
  assert.notEqual(refreshed.payload.note,oldWords);assert.equal(await page.locator('[data-preview-reminder-note]').textContent(),refreshed.payload.note);
  assert.equal((await state()).ledger[0].reminders_sent,0);assert.equal((await state()).external_calls,0);
  await action('[data-reject="'+refreshed.id+'"]');assert.deepEqual((await state()).pending,[]);
  check('public_controls','literal_USD_and_exact_multiline_reminder_then_same_day_partial_payment_invalidates_old_words',{old_action_id:reminder.id,new_action_id:refreshed.id,old_note:oldWords,new_note:refreshed.payload.note});
  report.final_state=await state();
  fs.writeFileSync(path.join(output,'public-worker-observation.json'),JSON.stringify(await page.evaluate(()=>window.__pr26Observation),null,2)+'\n');
  await Promise.all(responseTasks);
  for(const [asset,h] of Object.entries(sourcePins.delivered_asset_hashes)){
    const seen=report.served.find(x=>x.path===asset&&x.status===200);assert.ok(seen,'served asset '+asset);assert.equal(seen.sha256,h,asset);
  }
  for(const [asset,b] of Object.entries(sourcePins.delivered_python_blobs)){
    const seen=report.served.find(x=>x.path===asset&&x.status===200);assert.ok(seen,'served Python '+asset);assert.equal(seen.git_blob,b,asset);
  }
  assert.deepEqual(report.off_origin,[]);assert.deepEqual(report.page_errors,[]);
  report.ok=true;await context.close();
}catch(error){report.error=String(error);report.stack=error.stack;}
finally{
  if(browser)await browser.close();
  report.finished_at=new Date().toISOString();record();
  console.log(JSON.stringify({ok:report.ok,fixture_controls:report.fixture_controls.length,public_controls:report.public_controls.length,error:report.error,page_errors:report.page_errors,off_origin:report.off_origin}));
}
process.exitCode=report.ok?0:1;
