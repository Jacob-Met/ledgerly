# Independent receiving of Ledgerly's merged queued preview

**Accepted.** The implementation from PR26 is the receiving target. Our overlapping preview alternative remains unpublished. Seven previously frozen native payload fixtures now pass through the owner's exact renderer into real Chrome DOM, and three focused flows pass on the actual public deployment. No product source or dependency changed in this receiving pass.

## Source and delivery

PR26 merged as `f044ee3c5f77ab062d51684d8718f888e48540b2`, with owner head `aa6cbf5e7f6f6c6b5129c676c5b8e9ba6d74bad3`. All seven owner source/test/helper hashes match the published freeze. Removing the two imports and replacing only the original approval-list expression restores main.ts byte-for-byte to its prior source. The recovery-test delta supplies the real renderer to its existing VM fixture; assertions and fake-worker behavior are untouched.

The renderer receives `state.pending` directly. Every inserted value and action-ID attribute is escaped; invoice quantities, unit values and prior-payment strings undergo no numeric conversion. Reminder notes and invoice item text use `white-space: pre-wrap`. The existing click listener still accepts only the explicit approve/reject buttons and sends their action ID.

The actual public route is **https://jacobmetoyer.com/ledgerly/**; the GitHub Pages URL redirects there. PR26 merge CI `37778804368` and Pages run `37778804292` both report success. During receiving the public Python source advanced to current main `5493205cd69a32be75ed2f7dfc669b122efe5563`. All six delivered Python response blobs match that main's actual tree. Its only relevant difference from f044 is the independently owned webhook identity/current-invoice refresh change in agent.py. The preview source, bridge and other five Python runtime inputs remain identical. This pass does not relabel current public behavior as an execution of old f044 runtime code.

Both public attempts observed the exact owner-qualified main JS, CSS and Worker hashes, plus all four exact Pyodide0.29.3 runtime asset hashes. No cache reconstruction, package install or alternate runtime was used. The public driver used the established Mac Node26.3.0, Chrome154.0.8037.98 and Playwright. Native Node type stripping executed the unchanged standalone TypeScript renderer for the fixture DOM controls.

## Independent controls actually executed

The original fixture producer had already run four controls against the native Demo/Agent/ReviewableExtractor/SandboxMock, producing seven source-pinned queue snapshots. This pass did not rerun those producer controls. It verified their manifest and immutable inputs and rendered all seven with the owner module in real Chrome at a 390px viewport:

- USD quantity `2.50`, unit value `12.40`, prior payment `1.20`, due on receipt without an invented due date, and admitted markup/newline text remain exact and literal.
- JPY quantity `1.00`, unit value `1234` and prior payment `0` remain original strings.
- Two currencies keep distinct action IDs, and the post-rejection snapshot contains only its retained card.
- The original multiline partial-payment reminder matches its native subject and note exactly.
- The invalidated snapshot removes all old approval controls; the explicit-redraft snapshot renders the new action ID and new words.

All seven fixture DOM controls passed. They exercise actual renderer output and native payload contracts; the fixture page does not claim to run the full application or its Worker.

The separate public UI replay passed three grouped controls on the actual delivered application:

1. Native review fields produce the complete JPY invoice payload exactly equal to the independent frozen fixture. The card displays `1.00` and `JPY 1234`; keyboard collapse/expand changes neither Worker message count nor the complete latest state.
2. Analyzing a different GBP email retains the original queued JPY payload and displayed value. Its explicit rejection removes that action.
3. Native review/approval produces the USD `2.50 × 12.40`, prior `1.20` case. Its real overdue reminder exactly matches the independent multiline `29.8` fixture and can be selected without a Worker call. A same-day additional payment of `1.00` removes the old action and message. An explicit new scan creates a different action ID with exactly the independent `28.8` words. No reminder is sent; the new action is explicitly rejected.

The successful public replay ran from **2026-10-08T13:08:26.215Z to 13:08:35.059Z**, exit zero (9.26s process duration), with zero page errors, off-origin requests or external provider calls. Source and fixture hashes were rechecked after execution. Both actual public phone captures were opened and inspected: Japanese recipient text, original JPY values, multiline reminder text, and explicit approval buttons are readable without clipping in the captured cards.

## Original receiver failure preserved

The first attempt passed all seven fixture DOM controls, then stopped before public acceptance because the helper edited only the first of fixture07's two original line items. This correctly produced two currency cards, conflicting with the helper's intended single-item assertion. The correction removes the extra row through the existing review UI and asserts one row before submitting. Product source, queue/payload assertions and timeouts are unchanged. The successful replay ran public controls only; the seven already-passing fixture DOM controls were not repeated.

The original script, failing receipt and log remain intact alongside the corrected script and successful public receipt. A local ENOSPC interruption occurred while preparing the second helper, before execution; only verified duplicate generated runtime assets from our own held alternative were removed, retaining its last build and all source/evidence. Neither preparation issue is attributed to product behavior.

## Evidence custody

`native-evidence/evidence-v1/receipt.json` is the exact original receipt, SHA-256 `5af0404e0ceb11e7ce35c5c1e12274e94600273db2f0e4689da14c664edc0d75`. `native-evidence/evidence-v2/receipt.json` is the exact successful receipt, SHA-256 `ecaf9ced7c1fce9d2c02506dc34d40cb7c41863bcd975b424596b5c858c08f28`. Both include actual public response URLs, HTTP status, byte length, SHA-256 and Git blob.

The complete native packet is retained at `/Users/me/hamon-towerops-decision-trace-68094585a1c2/ledgerly-pr26-receiving/ledgerly-pr26-native-evidence.tar.gz`: **185,647 bytes**, SHA-256 `dc87951c3feae0c492472b4012857533870f5d9ed3724222264bbff9be1e83ba`, 22 members. It includes exact source-input and correction archives, both drivers and process logs, all captures and the actual public Worker transcript. Its manifest SHA-256 is `ab6c15efa011b277ac7b0a0a3712b68ee2762182c11e98650120251988e73db6`. The compact receiving packet preserves the review, exact receipts, scripts, source projection, correction record, native manifest and both inspected public captures.

Root owns the durable issue/PR handoff. This closes the receiving purpose of our duplicate preview handoff; the earlier owner's PR26 remains the implemented product.
