# Ledgerly PR21 receiving on current main

PR21 head `fe9cd6495dfa8f847d5902901bb045dd4690bfb3` composes cleanly with observed main `f044ee3c5f77ab062d51684d8718f888e48540b2`. The expected complete tree is `cc84de9a71fb23be5af6467a59f8e994c388114a` (340 leaves). All 253 current leaves outside the four modified PR21 paths survive exactly, including the newer approval outcomes and queued-preview contributions. The only automatically composed production file is Agent, blob `3ae7fcae5b1b243f608ab1bea6e25313a2fea091`.

`final-receiving-review.json` records acceptance, exact input/output identities, ownership boundaries, workflow implications and limits. `expected-pr21-on-f044-leaves.json` is the complete expected map for a normal merge with parents `[f044ee3c5f77ab062d51684d8718f888e48540b2, fe9cd6495dfa8f847d5902901bb045dd4690bfb3]`. Integration remains the root agent's responsibility, including a fresh head/current-main check and any hosted checkout identity relied on.

## Meaningful current native check

Three independent controls passed on the exact composed Agent using existing Python 3.12.14 / pytest 9.1.1. Unchanged main350 gives two expected failures and one retained control. Raw original and candidate output is preserved. The tests use real native Agent and SandboxMock with synthetic response-loss injection; there are no live provider requests.

1. A delayed payment snapshot preserves the exact reviewed GBP500 reminder; a subsequently completed reminder with a lost response consumes the approval, and a duplicate notification cannot reopen it.
2. An unavailable current read consumes no notification and changes no state. Retrying that webhook and separately retrying a failed read-only approval preflight each remain possible; one explicit approval sends once.
3. After send/deposit effects succeed but the final read fails, a later webhook can update the ledger without reopening the consumed send approval.

The current approval method is byte-exact. Replacing only the published webhook import, initializer and handler with their current counterparts restores the entire original Agent byte sequence. All 12 sparse source/fixture copies and the new control file were checked before and after execution. Main's subsequent PR26 preview change touches none of those native inputs, so no duplicate test run was performed.

From this packet directory, with pytest available, the tests can be received without other project files:

```sh
LEDGERLY_SOURCE="$PWD/native/candidate350-pr21" python -B -m pytest -p no:cacheprovider -q test_webhook_approval_composition.py
LEDGERLY_SOURCE="$PWD/native/baseline350" python -B -m pytest -p no:cacheprovider -q test_webhook_approval_composition.py
```

The second command intentionally reproduces two baseline failures. The retained receipt names the exact runtime originally used; these instructions do not imply the recipient's Python version is identical.

## Existing evidence and scope

Independent verification matched all 21 published receiving blobs, 20 published digest entries, 45 actual source/test/config inputs, 22 staged files and five Pyodide runtime files. Native Git three-way composition exactly reproduced the historical PR19-on1b2 tree `62ece84f647f757768b683c10eb7c67df31e9530` and old combined tree `7bbd3e34686e633e71908eb4f2bc4c0342451731`. Applying PR21's newer evidence-only delta yields `88411437ba6675160fcd38c6288bdb6903cadbc4`.

That published 246-test / 60-subtest plus 10-test Node/Pyodide qualification remains tied to its original source inputs. It is not represented as execution of the final current tree. PR19 is held separately because the root receiver found an uncaught large-quantity exception at the public extraction boundary. Its historical passing cases and original evidence are preserved.

The two adjusted existing assertions are accepted: decimal equality preserves the exact balance value without binding provider spelling; the delayed-snapshot control preserves exact current reviewed text and retains explicit approval, closed direct permits and one-use behavior.

The current CI workflow runs native pytest and npm audit/tests/build. An Agent change on main also triggers the separate Pages build/deploy workflow. This packet establishes source and bounded native receiving, with no new browser rendering claim, provider activation, external publication or deployment claim. The complete new preview source is preserved for its owner's separate receiving.

The root's read-only workflow copies had one extra trailing newline. `workflow-copy-observation.json` preserves that harmless input normalization finding; canonical Git bytes are retained here for workflow identity. Original source/evidence packets were not rewritten.
