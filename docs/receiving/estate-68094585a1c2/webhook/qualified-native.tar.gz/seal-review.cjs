const fs=require('fs'),path=require('path'),assert=require('assert/strict'),crypto=require('crypto'),cp=require('child_process');
const root=__dirname,read=p=>JSON.parse(fs.readFileSync(path.join(root,p)));
const current=read('current-f044-input.json'),initial=read('current-350-input.json'),provenance=read('source-composition-review.json');
const before=read('expected-pr21-on-350-leaves.json');
const map=t=>Object.fromEntries(t.tree.filter(x=>x.type!=='tree').map(({path,mode,type,sha})=>[path,{mode,type,sha}]));
const base=map(initial.tree),latest=map(current.tree),result={...before};
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),oid=(t,b)=>crypto.createHash('sha1').update(`${t} ${b.length}\0`).update(b).digest('hex');
function hash(leaves){const root={};for(const[p,e]of Object.entries(leaves)){let n=root,a=p.split('/');for(const k of a.slice(0,-1))n=n[k]??={};n[a.at(-1)]={leaf:e};}function h(n){return oid('tree',Buffer.concat(Object.entries(n).map(([name,v])=>v.leaf?{name,mode:v.leaf.mode,sha:v.leaf.sha,sort:name}:{name,mode:'40000',sha:h(v),sort:name+'/'}).sort((a,b)=>Buffer.compare(Buffer.from(a.sort),Buffer.from(b.sort))).flatMap(e=>[Buffer.from(`${e.mode} ${e.name}\0`),Buffer.from(e.sha,'hex')])));}return h(root);}
assert.equal(hash(latest),current.tree.sha);
const changes=[];
for(const p of new Set([...Object.keys(base),...Object.keys(latest)])){if(JSON.stringify(base[p])!==JSON.stringify(latest[p])){assert.deepEqual(before[p],base[p],'Unexpected overlap with PR21 '+p);if(latest[p])result[p]=latest[p];else delete result[p];changes.push(p);}}
const current21=provenance.compositions.find(x=>x.name==='pr21-on-350');
const unowned=Object.keys(latest).filter(p=>!current21.incoming_paths.includes(p));
for(const p of unowned)assert.deepEqual(result[p],latest[p]);
const freeze=read('native/source-freeze.json');
for(const e of freeze.source_files){const b=fs.readFileSync(path.join(root,'native',e.role,e.path));assert.equal(sha(b),e.sha256);assert.equal(oid('blob',b),e.git_blob);assert.equal((e.role==='candidate350-pr21'?result:latest)[e.path].sha,e.git_blob);}
assert.equal(sha(fs.readFileSync(path.join(root,freeze.test.path))),freeze.test.sha256);
const preview=read('current-preview-input.json');
for(const [k,p]of [['main','web-demo/src/main.ts'],['preview','web-demo/src/approval-preview.ts']]){assert.equal(oid('blob',Buffer.from(preview[k].content)),preview[k].sha);assert.equal(latest[p].sha,preview[k].sha);}
const workflows=[];
for(const [local,p]of [['current-ci.yml','.github/workflows/ci.yml'],['current-pages.yml','.github/workflows/pages.yml']]){const b=fs.readFileSync(path.join(root,local));assert.equal(oid('blob',b),latest[p].sha);workflows.push({path:p,git_blob:oid('blob',b),sha256:sha(b),local_copy:local});}
const runtime=JSON.parse(cp.execFileSync('/dev/shm/estate-60b2c08feb01-runtime/suite-venv/bin/python',['-B','-c','import sys,pytest,json; print(json.dumps({"python":sys.version,"pytest":pytest.__version__}))'],{encoding:'utf8'}));
const expected='expected-pr21-on-f044-leaves.json';
fs.writeFileSync(path.join(root,expected),JSON.stringify(result,null,2)+'\n');
const report={
  recorded_at:new Date().toISOString(),repository:'Jacob-Met/Ledgerly',
  disposition:'Accept PR21 source composition on exact observed current main; root owns expected-head integration and hosted receiving. PR19 remains held for the separately reported quantity boundary defect.',
  current:{commit:current.main.commit.sha,tree:current.tree.sha,leaves:Object.keys(latest).length},
  incoming:{pr:21,head:'fe9cd6495dfa8f847d5902901bb045dd4690bfb3',tree:'ea4b4cf24601c434a7595ace76efd8ebbb061c56'},
  expected_merge:{parents:[current.main.commit.sha,'fe9cd6495dfa8f847d5902901bb045dd4690bfb3'],tree:hash(result),leaves:Object.keys(result).length,source_agent:current21.source_merges[0],preserved_current_leaves:unowned.length,preserved_all_preview_delta_paths:changes.length,complete_leaf_map:expected},
  new_main_delta:{integration:'PR26 queued approval preview',parent:'350868091702d60f3dc340be4a017ba49d99f8a0',paths:changes,native_sources_unchanged:true,source_contract_review:'Actual preview renders pending action payload and exact id; existing main sends id through the unchanged bridge. PR21 changes neither pending action shape nor queue/approve/bridge methods. All UI source/test/docs bytes are preserved.'},
  source_preservation:{proof:'native/method-preservation.json',restoration_exact:true,current_approve_exact:true,published_webhook_methods_exact:true},
  native_controls:{source_tree_at_execution:'cc3607eb0d8b721254ddd227196cdf95f84ae19f',tested_native_modules_identical_in_final_composition:true,baseline:{commit:'350868091702d60f3dc340be4a017ba49d99f8a0',passed:1,failed:2,log:'native/baseline350.log'},candidate:{passed:3,failed:0,log:'native/candidate350-pr21.log'},cases:['Delayed payment notification preserves exact review, then a completed reminder with lost response consumes its approval ID; a duplicate notification cannot reopen it.','Unavailable webhook read consumes no event and changes no state; its retry and the distinct approval preflight retry remain valid, then exactly one reminder is sent.','After send/deposit succeeded but its final read failed, a webhook can refresh the ledger without reopening the consumed send approval.'],test:freeze.test,runtime,post_execution_all_12_source_pins_and_test_unchanged:true},
  historical_evidence:{exact_246_native_60_subtests_and_10_Node_Pyodide_tests:'Bound to original combined1b2 modules; retained as historical positives, not claimed as current final tree execution.',published_evidence_blobs:21,published_manifest_digests:20,frozen_source_test_config_inputs:45,staged_files:22,pyodide_runtime_files:5,independently_reconstructed_pr19_on1b2:'62ece84f647f757768b683c10eb7c67df31e9530',independently_reconstructed_old_pair:'7bbd3e34686e633e71908eb4f2bc4c0342451731',full_latest_evidence_only_pair:'88411437ba6675160fcd38c6288bdb6903cadbc4'},
  adjusted_existing_assertions:[{path:'tests/test_reminder_freshness.py',acceptance:'Decimal equality retains exact value500; valid current provider representation need not remain string500.00. Pending invalidation and absence of outgoing reminder remain asserted.'},{path:'tests/test_reminder_receiving.py',acceptance:'Current exact GBP500 reviewed text stays pending across delayed stale snapshot; no automatic send or direct permit is granted; explicit approval sends identical subject/note once and the same ID cannot replay.'}],
  ownership:{root_receiving_comment:'https://github.com/Jacob-Met/ledgerly/pull/21#issuecomment-6059704015',incoming_author:'estate-06e2ad0ce13f',preview_owner_preserved:'PR26 / work/approval-preview-5f566b5ec8ef',observed_comments_after_receiving_notice:0,publication_mutations_by_reviewer:0},
  gates:{workflow_pins:workflows,existing_pr_run:{id:37770834318,head:'fe9cd6495dfa8f847d5902901bb045dd4690bfb3',status:'success',scope:'Existing earlier PR run; not proof of currentf044 merged tree.'},required_current_hosted:'Root must bind any relied-on test checkout to actual expected merged tree. PR workflow runs Python pytest plus npm ci/audit/tests/build.',merge_effect:'Agent change matches main Pages path filter and triggers build/upload/deploy; actual production deployment is a separate receiving result.'},
  input_normalization_observation:'workflow-copy-observation.json records a harmless extra final LF in the root read copies; exact local Git bytes were used for canonical workflow identities. No product or test failure.',
  limits:['No live PayPal effect or provider activation.','No browser rendering or full current native suite rerun by this receiver.','Main and incoming head must be refreshed before integration; preserve further unrelated work.','Original and candidate modules, negative evidence and prior logs remain frozen.']
};
const bytes=Buffer.from(JSON.stringify(report,null,2)+'\n');fs.writeFileSync(path.join(root,'final-receiving-review.json'),bytes);
console.log(JSON.stringify({receipt:path.join(root,'final-receiving-review.json'),sha256:sha(bytes),current:report.current,expected_tree:report.expected_merge.tree,expected_leaves:report.expected_merge.leaves,preserved:unowned.length,latest_delta_paths:changes.length,agent:report.expected_merge.source_agent.merged_blob,runtime}));
