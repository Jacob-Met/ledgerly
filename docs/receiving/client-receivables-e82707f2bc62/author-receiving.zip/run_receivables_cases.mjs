import {pathToFileURL} from 'node:url';
import {writeFileSync, readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
const source = resolve(process.argv[2]);
const output = resolve(process.argv[3]);
const casesPath = resolve(import.meta.dirname, 'candidate/web-demo/tests/receivables-cases.ts');
const {receivablesCases} = await import(pathToFileURL(casesPath).href);
let product;
try { product = await import(pathToFileURL(resolve(source, 'web-demo/src/receivables.ts')).href); }
catch (error) {
  const result = {kind: 'source-absence', source, error: String(error), cases: receivablesCases.length,
    testSha256: createHash('sha256').update(readFileSync(casesPath)).digest('hex')};
  writeFileSync(output, JSON.stringify(result, null, 2) + '\n'); console.log(JSON.stringify(result)); process.exit(1);
}
const results = [];
for (const entry of receivablesCases) {
  try { entry.run(product.projectReceivables, product.receivablesFor); results.push({name: entry.name, passed: true}); }
  catch (error) { results.push({name: entry.name, passed: false, error: error.stack}); }
}
const result = {source, node: process.version, passed: results.filter(row => row.passed).length,
  failed: results.filter(row => !row.passed).length,
  testSha256: createHash('sha256').update(readFileSync(casesPath)).digest('hex'),
  sourceSha256: createHash('sha256').update(readFileSync(resolve(source, 'web-demo/src/receivables.ts'))).digest('hex'), results};
writeFileSync(output, JSON.stringify(result, null, 2) + '\n'); console.log(JSON.stringify(result, null, 2));
process.exit(result.failed ? 1 : 0);
