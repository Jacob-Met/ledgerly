"""Native baseline for a client receivables overview; synthetic SandboxMock only."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path

root = Path(__file__).resolve().parent
source = root / "baseline"
sys.path[:0] = [str(source), str(source / "web-demo/python")]
spec = importlib.util.spec_from_file_location("receivables_native_bridge", source / "web-demo/python/bridge.py")
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)
destination = root / "baseline-reproduction"
destination.mkdir(exist_ok=False)
calls = []

def call(action, **fields):
    raw = json.dumps({"action": action, **fields})
    result = json.loads(bridge.handle_json(raw))
    calls.append({"request": json.loads(raw), "response": result})
    if not result["ok"]:
        raise AssertionError(result)
    return result

def source_hashes():
    return {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(source.rglob("*")) if p.is_file() and "__pycache__" not in p.parts}

before = source_hashes()
opening = call("init")["state"]
start = date.fromisoformat(opening["today"])
jobs = [
    ("North Studio", "north@example.test", "USD", "0.10", 1, True, None),
    ("North Studio", "north@example.test", "USD", "0.20", 7, True, None),
    ("North Studio", "north@example.test", "EUR", "12.30", 14, True, None),
    ("South Studio", "south@example.test", "USD", "120.75", 1, True, "20.25"),
    ("South Studio", "south@example.test", "USD", "20.00", 1, True, "20.00"),
    ("North Studio", "north@example.test", "GBP", "9.99", 1, False, None),
]
for name, email, currency, amount, days, approve, payment in jobs:
    text = f"From: {name} <{email}>\n\n- 1 x Design work @ {currency} {amount}\nNet {days}\n"
    draft = call("draft", text=text)
    pending = draft["result"]["pending"]
    assert len(pending) == 1, draft
    action = pending[0]
    assert action["kind"] == "send_invoice"
    if approve:
        call("approve", action_id=action["id"])
    if payment:
        call("payment", invoice_id=action["invoice_id"], amount=payment)
final = call("advance", day=(start + timedelta(days=7)).isoformat())["state"]
after_read = call("init")["state"]
assert final == after_read
assert before == source_hashes()
assert final["external_calls"] == 0
rows = final["ledger"]
assert len(rows) == 6
north_usd = [r for r in rows if r["client_email"] == "north@example.test" and r["currency"] == "USD"]
assert sum((Decimal(r["balance"]) for r in north_usd), Decimal(0)) == Decimal("0.30")
south = [r for r in rows if r["client_email"] == "south@example.test" and r["status"] == "PARTIALLY_PAID"]
assert len(south) == 1 and Decimal(south[0]["balance"]) == Decimal("100.50")
states = {status: sum(r["status"] == status for r in rows) for status in ("DRAFT", "SENT", "PARTIALLY_PAID", "PAID")}
assert states == {"DRAFT": 1, "SENT": 3, "PARTIALLY_PAID": 1, "PAID": 1}
index = (source / "web-demo/index.html").read_text()
main = (source / "web-demo/src/main.ts").read_text()
assert "receivables" not in index.lower() and "receivables" not in main.lower()
assert "ledger.map(" in main
receipt = {
    "source_commit": "b9c24ace6b57a17215a53c50b674bd187d13f8ed",
    "source_tree": "0f457eb8ded2b462bd1be4d335c3a257cd19c630",
    "native_commands": len(calls), "external_calls": final["external_calls"],
    "unchanged_source": before == source_hashes(), "snapshot_read_unchanged": final == after_read,
    "ledger_rows": len(rows), "states": states, "snapshot_day": final["today"],
    "manual_native_receivables": {
        "north@example.test": {"USD": "0.30", "EUR": "12.30"},
        "south@example.test": {"USD": "100.50"},
        "not_counted": {"DRAFT": 1, "PAID": 1},
    },
    "missing_capability": "Current frontend only renders individual ledger cards; there is no client/currency balance or due-state overview.",
    "browser_executed": False,
    "source_hashes": before,
}
(destination / "commands.json").write_text(json.dumps(calls, indent=2) + "\n")
(destination / "snapshot.json").write_text(json.dumps(final, indent=2) + "\n")
(destination / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({k: v for k, v in receipt.items() if k != "source_hashes"}, indent=2))
