import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import http from 'node:http';
import assert from 'node:assert/strict';
import {chromium} from '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';

const appRoot = path.resolve(process.argv[2] || 'candidate/web-demo');
const out = path.resolve(process.argv[3] || 'receiving/browser-candidate');
fs.mkdirSync(out, {recursive:true});
const dist = path.join(appRoot,'dist');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const blob = bytes => crypto.createHash('sha1').update(Buffer.from('blob '+bytes.length+'\0')).update(bytes).digest('hex');
const pins = root => {
  const result = {};
  const walk = at => { for (const item of fs.readdirSync(at,{withFileTypes:true})) {
    const absolute=path.join(at,item.name); if(item.isDirectory()) walk(absolute);
    else {const bytes=fs.readFileSync(absolute);result[path.relative(root,absolute)]={bytes:bytes.length,sha256:sha(bytes),gitBlob:blob(bytes)};}
  }};
  walk(root);return result;
};
const before = pins(dist);
const lock=JSON.parse(fs.readFileSync(path.join(appRoot,'package-lock.json'),'utf8'));
const versions={};
for(const name of ['pyodide','typescript','vite','vitest']){
  const actual=JSON.parse(fs.readFileSync(path.join(appRoot,'node_modules',name,'package.json'),'utf8')).version;
  const expected=lock.packages['node_modules/'+name].version;
  assert.equal(actual,expected);versions[name]={actual,locked:expected};
}
const receipt={
 schema:'ledgerly.independent-browser-completed-reviews.v1',
 candidate:'17cc8a7ae3eb10083a037f7881c25af0510f6399',
 tree:'53d62c032e55af5fd45ca22a8d06521e463a5b2d',
 appRoot, node:process.version, packageVersions:versions,
 harnessSHA256:sha(fs.readFileSync(new URL(import.meta.url))),
 instrumentation:'An observational subclass forwards each native Worker constructor and postMessage unchanged and copies actual replies. No worker, Python function, API response, or product state is substituted. One declared ErrorEvent is delivered to the actual Worker to exercise the existing unavailability handler after ordinary receiving.',
 boundary:'Real compiled production app and self-hosted Pyodide running real Ledgerly/Agent/SandboxMock with fictional invoice data; loopback static delivery only. Explicit UI decisions affect only in-memory fictional sandbox state.',
 checks:[],requests:[],served:[],externalAttempts:[],pageErrors:[],consoleErrors:[],passed:false,
 distBefore:before
};
let browser, context, page;
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.py':'text/plain; charset=utf-8','.txt':'text/plain; charset=utf-8','.wasm':'application/wasm','.zip':'application/zip','.svg':'image/svg+xml'};
const server=http.createServer((req,res)=>{
 try {
  const u=new URL(req.url,'http://127.0.0.1');
  const relative=decodeURIComponent(u.pathname).replace(/^\/+/,'') || 'index.html';
  const file=path.resolve(dist,relative);
  if(!file.startsWith(dist+path.sep)||!['GET','HEAD'].includes(req.method)){res.writeHead(403);res.end();return;}
  if(!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404);res.end('Not found');receipt.served.push({method:req.method,path:relative,status:404});return;}
  const bytes=fs.readFileSync(file);
  receipt.served.push({method:req.method,path:relative,status:200,bytes:bytes.length,sha256:sha(bytes)});
  assert.equal(sha(bytes),before[relative].sha256,'served file must match frozen compiled bytes');
  res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','Content-Length':bytes.length,'Cache-Control':'no-store'});
  res.end(req.method==='HEAD'?undefined:bytes);
 } catch(e){receipt.serverError=String(e);res.writeHead(500);res.end('Receiver error');}
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const origin='http://127.0.0.1:'+server.address().port;
receipt.origin=origin;
const check=(name,details={})=>receipt.checks.push({name,passed:true,...details});
const lastState=async()=>page.evaluate(()=>[...window.__ledgerlyObserve.replies].reverse().find(x=>x.data?.state)?.data.state);
const counters=async()=>page.evaluate(()=>({posts:window.__ledgerlyObserve.requests.length,mock:Number(document.querySelector('#mock-requests').textContent),external:Number(document.querySelector('#external-calls').textContent)}));
const record= id=>page.locator('details.completed-review[data-review-id="'+id+'"]');
const outer= id=>record(id).locator(':scope > summary');
const nested= id=>record(id).locator('details.approval-preview > summary');
const focused=async(id,kind)=>page.evaluate(({id,kind})=>{
 const panel=document.querySelector('details.completed-review[data-review-id="'+id+'"]');
 const target=kind==='outer'?panel?.querySelector(':scope > summary'):panel?.querySelector('details.approval-preview > summary');
 return document.activeElement===target;
},{id,kind});
async function perform(action,activate){
 const count=await page.evaluate(()=>window.__ledgerlyObserve.requests.length);
 await activate();
 await page.waitForFunction(n=>window.__ledgerlyObserve.requests.length>n,count,{timeout:45000});
 const request=await page.evaluate(n=>window.__ledgerlyObserve.requests[n],count);
 assert.equal(request.action,action);
 await page.waitForFunction(id=>window.__ledgerlyObserve.replies.some(x=>x.id===id),request.id,{timeout:90000});
 const reply=await page.evaluate(id=>window.__ledgerlyObserve.replies.find(x=>x.id===id),request.id);
 assert.equal(reply.ok,true,JSON.stringify(reply)); assert.equal(reply.data?.ok,true,JSON.stringify(reply.data));
 await page.waitForFunction(()=>!document.querySelector('#analyze').disabled,{timeout:45000});
 assert.equal((await counters()).external,0);
 return reply.data;
}
async function activateThenFocus(selector,id,kind){
 await page.evaluate(({selector,id,kind})=>{
  document.querySelector(selector).click();
  const panel=document.querySelector('details.completed-review[data-review-id="'+id+'"]');
  (kind==='outer'?panel.querySelector(':scope > summary'):panel.querySelector('details.approval-preview > summary')).focus();
 },{selector,id,kind});
}
async function makeDraft(label,currency,keepFocus){
 const previous=new Set((await lastState()).pending.map(x=>x.id));
 const email='Independent receiving '+label+'. The structured corrections below are fictional and explicitly checked.';
 await page.locator('#job-email').fill(email);
 const analyzed=await perform('analyze',()=>keepFocus?activateThenFocus('#analyze',keepFocus,'nested'):page.locator('#analyze').click());
 if(keepFocus) assert(await focused(keepFocus,'nested'),'nested proposal focus survives actual analyze reply');
 await page.locator('#review-editor > summary').focus(); await page.keyboard.press('Enter');
 await page.locator('#review-client-name').fill('Málaga 日本語 '+label);
 await page.locator('#review-client-email').fill(label+'@receiver.example.test');
 await page.locator('#review-due-days').fill('2');
 await page.locator('#review-amount-paid').fill('0');
 while(await page.locator('[data-remove-line]').count()) await page.locator('[data-remove-line]').first().click();
 const lines=[
  {desc:'<spec> & "literal" '+label,qty:'2',price:'12.30',unit:'hours'},
  {desc:'Follow-up 日本語 '+label,qty:'1',price:'7.40',unit:''}
 ];
 for(let i=0;i<lines.length;i++){
  await page.locator('#review-add-line').click();
  await page.locator('#review-line-'+i+'-desc').fill(lines[i].desc);
  await page.locator('#review-line-'+i+'-qty').fill(lines[i].qty);
  await page.locator('#review-line-'+i+'-price').fill(lines[i].price);
  await page.locator('#review-line-'+i+'-currency').selectOption(currency);
  await page.locator('#review-line-'+i+'-unit').fill(lines[i].unit);
 }
 await page.locator('#review-confirm').check();
 const review=await perform('review',()=>page.locator('#review-check').click());
 assert.equal(review.result.valid,true);
 const drafted=await perform('draft',()=>page.locator('#draft').click());
 assert.equal(drafted.result.unauthorized_send_blocked,true);
 const added=drafted.state.pending.filter(x=>!previous.has(x.id));
 assert.equal(added.length,1); assert.equal(added[0].kind,'send_invoice');
 return {proposal:added[0],email,lines,analyzedSource:analyzed.result.source};
}
function originalFields(value){
 const result={...value};delete result.status;delete result.result;return result;
}
async function readRecord(id,expected){
 const panel=record(id);
 if((await panel.getAttribute('open'))===null) {await outer(id).focus();await page.keyboard.press('Enter');}
 assert.deepEqual(JSON.parse(await panel.locator('[data-review-result]').textContent()),expected.result);
 assert((await panel.textContent()).includes(expected.created_at));
 assert((await panel.textContent()).includes(expected.payload.invoice.items[0].name));
 assert.equal(await panel.locator('spec').count(),0);
 assert.equal(await panel.locator('button').count(),0);
}
try {
 browser=await chromium.launch({executablePath:'/workspace/scratch/3e50c5ad22c5/production/browser/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage'],downloadsPath:path.join(out,'downloads')});
 receipt.chromiumVersion=browser.version();
 context=await browser.newContext({viewport:{width:1280,height:900},serviceWorkers:'block'});
 await context.route('**/*',route=>{
  const url=new URL(route.request().url());
  receipt.requests.push({url:url.href,method:route.request().method(),type:route.request().resourceType()});
  if(url.origin===origin || ['blob:','data:','about:'].includes(url.protocol)) return route.continue();
  receipt.externalAttempts.push(url.href);return route.abort('blockedbyclient');
 });
 await context.addInitScript(()=>{
  const NativeWorker=window.Worker;
  window.__ledgerlyObserve={requests:[],replies:[],constructors:[],faults:[]};
  window.__ledgerlyNativeWorkers=[];
  window.Worker=class extends NativeWorker{
   constructor(url,options){
    super(url,options);
    window.__ledgerlyNativeWorkers.push(this);
    window.__ledgerlyObserve.constructors.push({url:String(url),options});
    this.addEventListener('message',event=>window.__ledgerlyObserve.replies.push(JSON.parse(JSON.stringify(event.data))));
   }
   postMessage(...args){
    window.__ledgerlyObserve.requests.push(JSON.parse(JSON.stringify(args[0])));
    return super.postMessage(...args);
   }
  };
 });
 page=await context.newPage();
 page.on('pageerror',error=>receipt.pageErrors.push(String(error)));
 page.on('console',msg=>{if(msg.type()==='error')receipt.consoleErrors.push(msg.text());});
 await page.goto(origin+'/',{waitUntil:'networkidle'});
 assert.match(await page.locator('#completed-reviews-note').textContent(),/Load the local engine/);
 const initial=await perform('init',()=>page.locator('#engine-start').click());
 assert.deepEqual(initial.state.completed_reviews,[]);
 assert.match(await page.locator('#engine-status').textContent(),/PYTHON READY/);
 check('Compiled app boots actual self-hosted Pyodide and a new empty native sandbox');

 const a=await makeDraft('earlier-a','EUR');
 const approved=await perform('approve',()=>page.locator('[data-approve="'+a.proposal.id+'"]').click());
 const savedA=approved.state.completed_reviews.find(x=>x.id===a.proposal.id);
 assert.equal(savedA.status,'APPROVED');assert.deepEqual(originalFields(savedA),originalFields(a.proposal));
 await readRecord(a.proposal.id,savedA);
 const beforeRead=await counters();
 await nested(a.proposal.id).focus();await page.keyboard.press('Space');
 assert.equal(await record(a.proposal.id).locator('details.approval-preview').getAttribute('open'),null);
 await page.keyboard.press('Enter');
 assert.notEqual(await record(a.proposal.id).locator('details.approval-preview').getAttribute('open'),null);
 assert.deepEqual(await counters(),beforeRead);
 check('Explicit native approval retains exact queued invoice and result; keyboard reading is literal and sends no worker request',{actionId:a.proposal.id,invoiceId:a.proposal.invoice_id,mockRequests:beforeRead.mock});

 const b=await makeDraft('later-b','USD',a.proposal.id);
 assert.deepEqual((await lastState()).completed_reviews.find(x=>x.id===a.proposal.id),savedA);
 await nested(a.proposal.id).focus();await page.keyboard.press('Space');
 assert.equal(await record(a.proposal.id).locator('details.approval-preview').getAttribute('open'),null);
 await page.locator('#payment-amount').fill('2.20');
 const payment=await perform('payment',()=>activateThenFocus('[data-pay="'+a.proposal.invoice_id+'"]',a.proposal.id,'outer'));
 assert.equal(payment.state.ledger.find(x=>x.invoice_id===a.proposal.invoice_id).status,'PARTIALLY_PAID');
 assert.deepEqual(payment.state.completed_reviews.find(x=>x.id===a.proposal.id),savedA);
 assert(await focused(a.proposal.id,'outer'));
 assert.equal(await record(a.proposal.id).locator('details.approval-preview').getAttribute('open'),null);
 const decidedB=await perform('reject',()=>activateThenFocus('[data-reject="'+b.proposal.id+'"]',a.proposal.id,'nested'));
 assert.deepEqual(decidedB.state.completed_reviews.map(x=>x.id),[b.proposal.id,a.proposal.id]);
 assert.deepEqual(decidedB.state.completed_reviews.find(x=>x.id===a.proposal.id),savedA);
 assert(await focused(a.proposal.id,'nested'),'same action nested focus is retained when new completed record prepends');
 assert.notEqual(await record(a.proposal.id).getAttribute('open'),null);
 assert.equal(await record(a.proposal.id).locator('details.approval-preview').getAttribute('open'),null);
 const savedB=decidedB.state.completed_reviews[0];assert.equal(savedB.status,'REJECTED');
 assert.deepEqual(originalFields(savedB),originalFields(b.proposal));
 assert.deepEqual(savedB.result,{reason:'Rejected by the browser visitor'});
 check('Changed source, partial payment and newer rejected review cannot rewrite earlier proposal; both disclosure states and action-specific focus survive real snapshot rerenders',{order:[b.proposal.id,a.proposal.id],originalResult:savedA.result});

 await page.setViewportSize({width:375,height:850});
 const narrowBefore=await counters();
 await outer(a.proposal.id).focus();await page.keyboard.press('Enter');
 assert.equal(await record(a.proposal.id).getAttribute('open'),null);
 await page.keyboard.press('Enter');await nested(a.proposal.id).focus();await page.keyboard.press('Enter');
 await readRecord(a.proposal.id,savedA);
 const dimensions=await page.evaluate(()=>({viewport:innerWidth,scroll:document.documentElement.scrollWidth}));
 assert(dimensions.scroll<=dimensions.viewport+2,JSON.stringify(dimensions));
 assert.deepEqual(await counters(),narrowBefore);
 await record(a.proposal.id).scrollIntoViewIfNeeded();
 await page.screenshot({path:path.join(out,'completed-review-narrow.png'),fullPage:false});
 const image=fs.readFileSync(path.join(out,'completed-review-narrow.png'));
 receipt.screenshot={path:'completed-review-narrow.png',bytes:image.length,sha256:sha(image)};
 check('375px native keyboard disclosure flow remains within page width and performs no sandbox operation',{dimensions});

 page.once('dialog',dialog=>dialog.accept());
 const reset=await perform('reset',()=>page.locator('#reset-sandbox').click());
 assert.deepEqual(reset.state.completed_reviews,[]);assert.deepEqual(reset.state.pending,[]);
 assert.equal(await page.locator('details.completed-review').count(),0);
 assert.equal(await page.locator('#job-email').inputValue(),'');
 assert.equal((await counters()).mock,0);
 check('Explicit reset discards native completed history and pending queue without retaining stale DOM records');

 await page.setViewportSize({width:1100,height:850});
 const c=await makeDraft('unavailable-c','EUR');
 const rejectedC=await perform('reject',()=>page.locator('[data-reject="'+c.proposal.id+'"]').click());
 const savedC=rejectedC.state.completed_reviews[0];
 await readRecord(c.proposal.id,savedC);
 const beforeFault=await counters();
 await page.evaluate(()=>{
  const fault={kind:'actual-worker-error-event',message:'Declared independent receiver worker unavailability',requestCount:window.__ledgerlyObserve.requests.length};
  window.__ledgerlyObserve.faults.push(fault);
  window.__ledgerlyNativeWorkers.at(-1).dispatchEvent(new ErrorEvent('error',{message:fault.message,cancelable:true}));
 });
 await page.waitForFunction(()=>document.querySelector('#engine-status').textContent==='PYTHON UNAVAILABLE');
 assert.match(await page.locator('#completed-reviews-note').textContent(),/last received reviews.*empty history; no action is replayed/);
 assert.equal(await page.locator('#engine-start').textContent(),'Restart empty sandbox');
 assert.equal(await page.locator('#job-email').inputValue(),c.email);
 assert.equal(await page.locator('#review-client-name').inputValue(),'Málaga 日本語 unavailable-c');
 assert.deepEqual(await counters(),beforeFault);
 await readRecord(c.proposal.id,savedC);assert.deepEqual(await counters(),beforeFault);
 const restart=await perform('init',()=>page.locator('#engine-start').click());
 assert.deepEqual(restart.state.completed_reviews,[]);assert.deepEqual(restart.state.pending,[]);
 assert.equal(await page.locator('details.completed-review').count(),0);
 assert.equal(await page.locator('#job-email').inputValue(),c.email);
 assert.equal(await page.locator('#review-client-name').inputValue(),'Málaga 日本語 unavailable-c');
 const afterFault=await counters();assert.equal(afterFault.posts,beforeFault.posts+1);assert.equal(afterFault.mock,0);
 assert.equal(await page.evaluate(()=>window.__ledgerlyObserve.constructors.length),2);
 check('Declared actual Worker unavailability labels last received history honestly; explicit restart creates empty history, retains human input and replays no operation');

 receipt.finalCounters=await counters();
 assert.equal(receipt.externalAttempts.length,0);
 assert.equal(receipt.pageErrors.length,0);
 assert.equal(receipt.consoleErrors.length,0);
 assert.equal(receipt.serverError,undefined);
 receipt.passed=true;
} catch(error) {
 receipt.error={name:error.name,message:error.message,stack:error.stack};
 if(page) try {await page.screenshot({path:path.join(out,'failure.png'),fullPage:false});}catch{}
 process.exitCode=1;
} finally {
 if(page) try {receipt.workerObservation=await page.evaluate(()=>window.__ledgerlyObserve);}catch{}
 receipt.distAfter=pins(dist);
 receipt.distUnchanged=JSON.stringify(receipt.distAfter)===JSON.stringify(before);
 if(!receipt.distUnchanged){receipt.passed=false;process.exitCode=1;}
 await context?.close();await browser?.close();
 await new Promise(resolve=>server.close(resolve));
 const target=path.join(out,'receipt.json');
 fs.writeFileSync(target,JSON.stringify(receipt,null,2)+'\n');
 const bytes=fs.readFileSync(target);
 console.log(JSON.stringify({passed:receipt.passed,checks:receipt.checks,requests:receipt.requests.length,served:receipt.served.length,externalAttempts:receipt.externalAttempts,pageErrors:receipt.pageErrors,consoleErrors:receipt.consoleErrors,error:receipt.error,receipt:target,bytes:bytes.length,sha256:sha(bytes),distUnchanged:receipt.distUnchanged}));
}
