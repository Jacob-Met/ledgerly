import hashlib,json,pathlib,shutil,os
R=pathlib.Path.cwd()
record=json.loads((R/'receiving/successor-admission-input.json').read_text())
overlays=json.loads((R/'receiving/successor-overlays.json').read_text())
target=R/'receiving/successor-source'
assert not target.exists()
target.mkdir()
actual={}
for name,pin in record['sourcePaths'].items():
 p=target/name;p.parent.mkdir(parents=True,exist_ok=True)
 data=overlays[name].encode() if name in overlays else (R/'candidate'/name).read_bytes()
 blob=hashlib.sha1(('blob '+str(len(data))+'\0').encode()+data).hexdigest()
 assert blob==pin['sha'],(name,blob,pin['sha'])
 p.write_bytes(data);p.chmod(0o444)
 actual[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'gitBlob':blob}
os.symlink(R/'candidate/web-demo/node_modules',target/'web-demo/node_modules')
record['materializedSource']=actual
p=R/'receiving/successor-source-admission.json';p.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'source':str(target),'files':len(actual),'sourceBodiesExact':True,'admission':{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}}))
