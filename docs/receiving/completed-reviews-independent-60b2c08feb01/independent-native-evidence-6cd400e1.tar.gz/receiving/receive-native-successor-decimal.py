"""Independent native receiving for Ledgerly completed-review history.

The oracle reads original PendingAction attributes through JSON serialization,
never the candidate projection or PendingAction.to_dict. All commands use the
actual bridge.handle_json and fictional SandboxMock state.
"""
from __future__ import annotations
import copy
from datetime import date, timedelta
import hashlib
import json
from pathlib import Path
import socket
import sys
import traceback

source = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
output.mkdir(parents=True, exist_ok=True)
sys.path[:0] = [str(source / 'web-demo/python'), str(source)]
network_attempts = []
OriginalSocket = socket.socket
class LocalNoNetworkSocket(OriginalSocket):
    def connect(self, address):
        network_attempts.append(repr(address))
        raise AssertionError('No native receiver network connection is permitted')
    def connect_ex(self, address):
        network_attempts.append(repr(address))
        raise AssertionError('No native receiver network connection is permitted')
socket.socket = LocalNoNetworkSocket

import bridge
from ledgerly.paypal import PayPalError

KEYS = ('id', 'kind', 'invoice_id', 'summary', 'payload', 'status', 'result', 'created_at')
def detached(value):
    return json.loads(json.dumps(value, ensure_ascii=False, default=str))
def original(action):
    return detached({name: getattr(action, name) for name in KEYS})
def expected(demo):
    return [original(action) for action in reversed(list(demo.agent.pending.values()))
            if action.status in ('APPROVED', 'REJECTED', 'FAILED')]

pins = {}
for name in ['ledgerly/__init__.py', 'ledgerly/agent.py', 'ledgerly/extract.py',
             'ledgerly/paypal.py', 'web-demo/python/bridge.py', 'web-demo/python/review.py',
             'web-demo/python/invoice_details.py', 'web-demo/python/review_history.py']:
    p = source / name
    if p.exists():
        b = p.read_bytes()
        pins[name] = {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(),
                     'gitBlob': hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()}
report = {'schema': 'ledgerly.independent-native-completed-reviews.v1',
          'source': str(source), 'sourcePins': pins, 'python': sys.version,
          'oracle': 'Direct original PendingAction attributes serialized through JSON, without calling to_dict or completed_reviews.',
          'checks': [], 'trace': [], 'passed': False, 'networkAttempts': network_attempts,
          'productSourceEdits': False, 'fixtureBoundary': 'Only fictional in-memory SandboxMock lifecycle. One loss-after-actual-send wrapper and one native provider-side prior-send fixture are explicit.'}
def record(name, **details):
    report['checks'].append({'name': name, 'passed': True, **details})
def new_demo():
    demo = bridge.Demo()
    demo.clock.day = date(2026, 10, 8)
    bridge.SESSION = demo
    return demo
def call(demo, action, **fields):
    assert bridge.SESSION is demo
    before = len(demo.mock.requests)
    response = json.loads(bridge.handle_json(json.dumps({'action': action, **fields}, ensure_ascii=False)))
    report['trace'].append({'action': action, 'ok': response['ok'],
                            'mockBefore': before, 'mockAfter': len(demo.mock.requests),
                            'error': response.get('error'), 'message': response.get('message'),
                            'historyCount': len(response['state'].get('completed_reviews', [])),
                            'pendingCount': len(response['state']['pending'])})
    assert response['state']['external_calls'] == 0
    return response
def require_ok(response):
    assert response['ok'], response
    return response
def draft(demo, label, currency='EUR'):
    text = f'Original fictional source for {label}. The reviewer will supply the exact invoice fields.'
    fields = {'client_name': f'Málaga 日本語 {label}', 'client_email': f'{label}@receiver.example.test',
              'due_days': '2', 'amount_paid': '0',
              'line_items': [
                  {'desc': f'<spec> & "literal" {label}', 'qty': '2', 'unit_price': '12.30',
                   'currency': currency, 'unit': 'hours'},
                  {'desc': f'Follow-up 日本語 {label}', 'qty': '1', 'unit_price': '7.40',
                   'currency': currency, 'unit': ''}]}
    before = len(demo.mock.requests)
    require_ok(call(demo, 'analyze', text=text))
    reviewed = require_ok(call(demo, 'review', text=text, fields=fields, confirmed=True))
    assert reviewed['result']['valid'] is True
    assert len(demo.mock.requests) == before
    existing_ids = set(demo.agent.pending)
    response = require_ok(call(demo, 'draft', text=text, review_id=reviewed['result']['review_id']))
    assert response['result']['unauthorized_send_blocked'] is True
    action = next(a for a in demo.agent.pending.values()
                  if a.status == 'PENDING' and a.id not in existing_ids)
    assert demo.mock.invoices[action.invoice_id]['status'] == 'DRAFT'
    assert action.payload and label in json.dumps(action.payload, ensure_ascii=False)
    return action.id, action.invoice_id, original(action)
def history(demo, snapshot=None):
    state = demo.snapshot() if snapshot is None else snapshot
    assert 'completed_reviews' in state, 'BASELINE_MISSING_HISTORY: actual native snapshot has no completed_reviews field'
    rows = state['completed_reviews']
    assert rows == expected(demo), {'observed': rows, 'expected': expected(demo)}
    return rows

from decimal import Decimal
report.update({
    'schema': 'ledgerly.independent-successor-value-history.v1',
    'candidate': '6cd400e1a0c4c9fd79016d57d5cf24d0b49f4906',
    'tree': '4249cf3905d4ac26dc1124e599be835982f11eb2',
    'scope': 'Only changed exact-value admission, canonical quantity serialization, and approved-review retention through payment.',
    'fixtureBoundary': 'Actual bridge/Agent/SandboxMock; fixed fictional date and explicit human review. No provider response wrapper or worker fault in this successor continuation.',
})
admission=json.loads((source.parent/'successor-source-admission.json').read_text())
def check_all_source():
    for name,pin in admission['materializedSource'].items():
        assert hashlib.sha256((source/name).read_bytes()).hexdigest()==pin['sha256'],name
    return {'files':len(admission['materializedSource']),'allExact':True}
report['sourceBefore']=check_all_source()
try:
    demo=new_demo()
    require_ok(call(demo,'init'))
    text='Independent successor integration. Human-reviewed fictional invoice.'
    fields={
        'client_name':'Málaga 日本語 successor','client_email':'successor@receiver.example.test',
        'due_days':'2','amount_paid':'0',
        'line_items':[
            {'desc':'<spec> & "literal" successor','qty':'2.00000','unit_price':'0.001','currency':'EUR','unit':'hours'},
            {'desc':'Follow-up 日本語 successor','qty':'1','unit_price':'7.40','currency':'EUR','unit':''},
        ],
    }
    require_ok(call(demo,'analyze',text=text))
    refused=require_ok(call(demo,'review',text=text,fields=fields,confirmed=True))
    assert refused['result']['valid'] is False
    assert not demo.mock.requests and not demo.mock.invoices and not demo.agent.pending
    assert not demo.agent.ledger
    assert any('unit_price' in issue['field'] and issue['severity']=='error' for issue in refused['result']['issues'])
    record('Current fractional currency-unit refusal occurs before invoice or approval allocation',
           issues=refused['result']['issues'],mockRequests=0)

    fields['line_items'][0]['unit_price']='12.30'
    accepted=require_ok(call(demo,'review',text=text,fields=fields,confirmed=True))
    assert accepted['result']['valid'] is True
    drafted=require_ok(call(demo,'draft',text=text,review_id=accepted['result']['review_id']))
    assert drafted['result']['unauthorized_send_blocked'] is True
    assert len(demo.agent.pending)==1
    action=next(iter(demo.agent.pending.values()))
    queued=original(action)
    invoice=queued['payload']['invoice']
    assert [row['quantity'] for row in invoice['items']]==['2','1']
    assert [row['unit_amount']['value'] for row in invoice['items']]==['12.30','7.40']
    assert invoice['items'][0]['name']=='<spec> & "literal" successor'
    assert demo.mock.invoices[action.invoice_id]['status']=='DRAFT'
    record('Actual current build_invoice serializes reviewed 2.00000 as canonical quantity 2 without changing original price strings',
           actionId=action.id,invoiceId=action.invoice_id,queued=queued)

    approved=require_ok(call(demo,'approve',action_id=action.id))
    retained=original(action)
    assert retained['status']=='APPROVED'
    for name in ['id','kind','invoice_id','summary','payload','created_at']:
        assert retained[name]==queued[name]
    assert approved['state']['completed_reviews']==[retained]
    payment=require_ok(call(demo,'payment',invoice_id=action.invoice_id,amount='2.20'))
    assert payment['state']['completed_reviews']==[retained]
    assert approved['state']['completed_reviews']==[retained]
    ledger=next(row for row in payment['state']['ledger'] if row['invoice_id']==action.invoice_id)
    assert ledger['status']=='PARTIALLY_PAID'
    assert Decimal(ledger['paid_amount'])==Decimal('2.20') and Decimal(ledger['balance'])==Decimal('29.80'), ledger
    record('Current payment updates the actual invoice and preserves the original approved proposal and recorded result',
           retained=retained,laterLedger=ledger)
    assert not network_attempts
    report['passed']=True
except Exception as error:
    report['failure']={'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
    report['sourceAfter']=check_all_source()
    report['sourceUnchanged']=report['sourceBefore']==report['sourceAfter']
    report['harnessSHA256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    p=output/'receipt.json';p.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'passed':report['passed'],'checks':len(report['checks']),'failure':report.get('failure'),
                      'networkAttempts':network_attempts,'sourceUnchanged':report['sourceUnchanged'],
                      'receipt':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
sys.exit(0 if report['passed'] and report['sourceUnchanged'] else 1)
