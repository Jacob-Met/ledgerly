import ast,hashlib,json,pathlib
R=pathlib.Path.cwd()
inp=json.loads((R/'receiving/final-source-boundary-input.json').read_text())
def git_tree(leaves):
 root={}
 for item in leaves:
  parts=item['path'].split('/');node=root
  for part in parts[:-1]:node=node.setdefault(part,{})
  node[parts[-1]]=(item['mode'],item['sha'])
 def emit(node):
  rows=[]
  for name,value in node.items():
   if isinstance(value,dict):mode,sha='40000',emit(value)
   else:mode,sha=value
   rows.append((name,mode,sha))
  rows.sort(key=lambda x:(x[0]+('/' if x[1]=='40000' else '')).encode())
  body=b''.join(mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(sha) for name,mode,sha in rows)
  return hashlib.sha1(('tree '+str(len(body))+'\0').encode()+body).hexdigest()
trees={}
for label,record in inp['trees'].items():
 computed=git_tree(record['leaves']);assert computed==record['tree']
 trees[label]={'commit':record['commit'],'tree':computed,'leaves':len(record['leaves']),'allLeavesReconstructed':True}
maps={label:{x['path']:(x['mode'],x['sha']) for x in record['leaves']} for label,record in inp['trees'].items()}
current,successor=maps['currentMain'],maps['successor']
changed=[p for p in sorted(set(current)|set(successor)) if current.get(p)!=successor.get(p)]
removed=[p for p in current if p not in successor]
assert not removed
fragments=inp['originalMainComposition']['fragments']
def remove(text):
 for fragment in fragments:
  assert text.count(fragment)==1
  text=text.replace(fragment,'')
 return text
candidate=(R/'candidate/web-demo/src/main.ts').read_text()
baseline=(R/'baseline/web-demo/src/main.ts').read_text()
latest=(R/'receiving/successor-source/web-demo/src/main.ts').read_text()
assert remove(candidate)==baseline
assert remove(latest)==inp['currentMainSource']
def methods(data):
 tree=ast.parse(data);lines=data.splitlines(True);out={}
 def walk(items,prefix=''):
  for n in items:
   if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
    start=min([d.lineno for d in getattr(n,'decorator_list',[])]+[n.lineno])-1
    out[prefix+n.name]=''.join(lines[start:n.end_lineno])
    if isinstance(n,ast.ClassDef):walk(n.body,prefix+n.name+'.')
 walk(tree.body);return out
functions={}
for name in ['ledgerly/agent.py','ledgerly/extract.py','ledgerly/paypal.py']:
 old=methods((R/'candidate'/name).read_text())
 new=methods((R/'receiving/successor-source'/name).read_text())
 functions[name]={'same':sorted(k for k in old.keys()&new.keys() if old[k]==new[k]),'changed':sorted(k for k in old.keys()&new.keys() if old[k]!=new[k]),'added':sorted(new.keys()-old.keys()),'removed':sorted(old.keys()-new.keys())}
 for p in [name]:assert successor[p]==current[p]
assert 'Agent.approve' in functions['ledgerly/agent.py']['same']
assert 'Agent.reject' in functions['ledgerly/agent.py']['same']
assert 'PendingAction.to_dict' in functions['ledgerly/agent.py']['same']
assert 'SandboxMock' in functions['ledgerly/paypal.py']['same']
sourceRecord=json.loads((R/'receiving/successor-source-admission.json').read_text())
for name,pin in sourceRecord['materializedSource'].items():assert hashlib.sha256((R/'receiving/successor-source'/name).read_bytes()).hexdigest()==pin['sha256']
lock=json.loads((R/'candidate/web-demo/package-lock.json').read_text())
installed={}
for name,pin in lock['packages'].items():
 if not name:continue
 p=R/'candidate/web-demo'/name/'package.json'
 if p.is_file():
  value=json.loads(p.read_text())['version'];assert value==pin['version']
  installed[name]={'version':value,'integrity':pin.get('integrity')}
browserReceipts={}
for label in ['browser-candidate','browser-successor']:
 p=R/'receiving'/label/'receipt.json';data=json.loads(p.read_text())
 source=R/'candidate' if label=='browser-candidate' else R/'receiving/successor-source'
 for name,pin in data['distBefore'].items():
  if name.startswith('python/'):
   sub=name[len('python/'):]
   original=source/sub if sub.startswith('ledgerly/') else source/'web-demo/python'/sub
   assert hashlib.sha256(original.read_bytes()).hexdigest()==pin['sha256'],name
 for served in data['served']:
  assert served['status']==200
  assert served['sha256']==data['distBefore'][served['path']]['sha256']
 browserReceipts[label]={'receiptSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'allServedBytesMatchFrozenDist':True,'allStagedPythonBytesMatchExactGitSource':True,'deliveryCount':len(data['served'])}
runtime={}
for name,p in {
 'chromium':pathlib.Path('/workspace/scratch/3e50c5ad22c5/production/browser/chromium'),
 'playwright_package':pathlib.Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/package.json'),
}.items():
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 runtime[name]={'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
runtime['playwrightVersion']=json.loads(pathlib.Path(runtime['playwright_package']['path']).read_text())['version']
result={'schema':'ledgerly.independent.final-source-review.v1','trees':trees,
 'currentMainPreservation':{'unchangedLeaves':sum(current[p]==successor[p] for p in current),'modifiedExistingLeaves':[p for p in changed if p in current],'addedLeaves':len([p for p in changed if p not in current]),'removedLeaves':removed},
 'mainComposition':{'exactThreeHistoryFragmentsPreserved':True,'removingThemReconstructsBaselineAndCurrentMainByteForByte':True,'fragments':fragments},
 'nativeFunctions':functions,'materializedSuccessorSource':{'files':48,'allExactAfterBuildAndRuns':True},
 'installedPackages':installed,'browserBindings':browserReceipts,'runtime':runtime,
 'carryForward':'Only source-identical history rendering, disclosure/focus, literal content, reset and unavailable behavior carry from exact17cc. Successor6cd receives new real strict-value/canonical-quantity/approved-review/payment execution; no claim that the full six old browser groups ran on the final bundle.',
 'limits':'No full owner test suite or current provider/site acceptance is claimed. Original author owns source, integration and hosted gates.'}
p=R/'receiving/final-source-review.json';p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'trees':trees,'installedPackages':len(installed),'browserBindings':browserReceipts,'source':result['materializedSuccessorSource']}))
