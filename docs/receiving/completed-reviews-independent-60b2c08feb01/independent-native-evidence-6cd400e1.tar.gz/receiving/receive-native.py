"""Independent native receiving for Ledgerly completed-review history.

The oracle reads original PendingAction attributes through JSON serialization,
never the candidate projection or PendingAction.to_dict. All commands use the
actual bridge.handle_json and fictional SandboxMock state.
"""
from __future__ import annotations
import copy
from datetime import date, timedelta
import hashlib
import json
from pathlib import Path
import socket
import sys
import traceback

source = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
output.mkdir(parents=True, exist_ok=True)
sys.path[:0] = [str(source / 'web-demo/python'), str(source)]
network_attempts = []
OriginalSocket = socket.socket
class LocalNoNetworkSocket(OriginalSocket):
    def connect(self, address):
        network_attempts.append(repr(address))
        raise AssertionError('No native receiver network connection is permitted')
    def connect_ex(self, address):
        network_attempts.append(repr(address))
        raise AssertionError('No native receiver network connection is permitted')
socket.socket = LocalNoNetworkSocket

import bridge
from ledgerly.paypal import PayPalError

KEYS = ('id', 'kind', 'invoice_id', 'summary', 'payload', 'status', 'result', 'created_at')
def detached(value):
    return json.loads(json.dumps(value, ensure_ascii=False, default=str))
def original(action):
    return detached({name: getattr(action, name) for name in KEYS})
def expected(demo):
    return [original(action) for action in reversed(list(demo.agent.pending.values()))
            if action.status in ('APPROVED', 'REJECTED', 'FAILED')]

pins = {}
for name in ['ledgerly/__init__.py', 'ledgerly/agent.py', 'ledgerly/extract.py',
             'ledgerly/paypal.py', 'web-demo/python/bridge.py', 'web-demo/python/review.py',
             'web-demo/python/invoice_details.py', 'web-demo/python/review_history.py']:
    p = source / name
    if p.exists():
        b = p.read_bytes()
        pins[name] = {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(),
                     'gitBlob': hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()}
report = {'schema': 'ledgerly.independent-native-completed-reviews.v1',
          'source': str(source), 'sourcePins': pins, 'python': sys.version,
          'oracle': 'Direct original PendingAction attributes serialized through JSON, without calling to_dict or completed_reviews.',
          'checks': [], 'trace': [], 'passed': False, 'networkAttempts': network_attempts,
          'productSourceEdits': False, 'fixtureBoundary': 'Only fictional in-memory SandboxMock lifecycle. One loss-after-actual-send wrapper and one native provider-side prior-send fixture are explicit.'}
def record(name, **details):
    report['checks'].append({'name': name, 'passed': True, **details})
def new_demo():
    demo = bridge.Demo()
    demo.clock.day = date(2026, 10, 8)
    bridge.SESSION = demo
    return demo
def call(demo, action, **fields):
    assert bridge.SESSION is demo
    before = len(demo.mock.requests)
    response = json.loads(bridge.handle_json(json.dumps({'action': action, **fields}, ensure_ascii=False)))
    report['trace'].append({'action': action, 'ok': response['ok'],
                            'mockBefore': before, 'mockAfter': len(demo.mock.requests),
                            'error': response.get('error'), 'message': response.get('message'),
                            'historyCount': len(response['state'].get('completed_reviews', [])),
                            'pendingCount': len(response['state']['pending'])})
    assert response['state']['external_calls'] == 0
    return response
def require_ok(response):
    assert response['ok'], response
    return response
def draft(demo, label, currency='EUR'):
    text = f'Original fictional source for {label}. The reviewer will supply the exact invoice fields.'
    fields = {'client_name': f'Málaga 日本語 {label}', 'client_email': f'{label}@receiver.example.test',
              'due_days': '2', 'amount_paid': '0',
              'line_items': [
                  {'desc': f'<spec> & "literal" {label}', 'qty': '2', 'unit_price': '12.30',
                   'currency': currency, 'unit': 'hours'},
                  {'desc': f'Follow-up 日本語 {label}', 'qty': '1', 'unit_price': '7.40',
                   'currency': currency, 'unit': ''}]}
    before = len(demo.mock.requests)
    require_ok(call(demo, 'analyze', text=text))
    reviewed = require_ok(call(demo, 'review', text=text, fields=fields, confirmed=True))
    assert reviewed['result']['valid'] is True
    assert len(demo.mock.requests) == before
    existing_ids = set(demo.agent.pending)
    response = require_ok(call(demo, 'draft', text=text, review_id=reviewed['result']['review_id']))
    assert response['result']['unauthorized_send_blocked'] is True
    action = next(a for a in demo.agent.pending.values()
                  if a.status == 'PENDING' and a.id not in existing_ids)
    assert demo.mock.invoices[action.invoice_id]['status'] == 'DRAFT'
    assert action.payload and label in json.dumps(action.payload, ensure_ascii=False)
    return action.id, action.invoice_id, original(action)
def history(demo, snapshot=None):
    state = demo.snapshot() if snapshot is None else snapshot
    assert 'completed_reviews' in state, 'BASELINE_MISSING_HISTORY: actual native snapshot has no completed_reviews field'
    rows = state['completed_reviews']
    assert rows == expected(demo), {'observed': rows, 'expected': expected(demo)}
    return rows

try:
    demo = new_demo()
    ready = require_ok(call(demo, 'init'))
    assert ready['state']['pending'] == [] and len(demo.mock.requests) == 0
    a, ia, original_a = draft(demo, 'earlier-a')
    b, ib, original_b = draft(demo, 'later-b', 'USD')
    # Completion order deliberately opposes creation order.
    require_ok(call(demo, 'approve', action_id=b))
    require_ok(call(demo, 'reject', action_id=a))
    assert demo.agent.pending[b].status == 'APPROVED'
    assert demo.agent.pending[a].status == 'REJECTED'
    assert not demo.agent.list_pending()
    assert demo.mock.invoices[ib]['status'] == 'SENT'
    assert demo.mock.invoices[ia]['status'] == 'DRAFT'
    record('Healthy native commands create only gated mock drafts and honor two explicit decisions',
           approved=b, rejected=a, auditRows=len(demo.agent.audit), mockRequests=len(demo.mock.requests))
    rows = history(demo)
    assert [row['id'] for row in rows] == [b, a], 'Order is most recently queued, not latest decision'
    for aid, queued in [(a, original_a), (b, original_b)]:
        current = next(row for row in rows if row['id'] == aid)
        for name in ('id', 'kind', 'invoice_id', 'summary', 'payload', 'created_at'):
            assert current[name] == queued[name]
    report['opposedDecisionOrder'] = {'queued': [a, b], 'completed': [b, a], 'displayed': [b, a],
                                      'records': detached(rows)}
    record('Completed records preserve original proposals and queue order after the queue becomes empty')

    before_records = expected(demo)
    old_snapshot = detached(demo.snapshot())
    request_before = detached(demo.mock.requests)
    audit_before = detached(demo.agent.audit)
    for _ in range(4):
        assert history(demo) == before_records
    assert detached(demo.mock.requests) == request_before
    assert detached(demo.agent.audit) == audit_before
    # Mutate a genuinely nested proposal object as well as recorded result.
    returned = demo.snapshot()['completed_reviews']
    nested = returned[0]['payload']['invoice']['items'][0]
    nested['name'] = 'RECEIVER CHANGED ONLY THE RETURNED COPY'
    returned[0]['result']['receiver'] = {'nested': ['returned copy']}
    assert expected(demo) == before_records
    assert old_snapshot['completed_reviews'] == before_records
    require_ok(call(demo, 'analyze', text='Another source, not either retained invoice.'))
    require_ok(call(demo, 'payment', invoice_id=ib, amount='1.20'))
    assert history(demo) == before_records
    assert demo.mock.invoices[ib]['status'] == 'PARTIALLY_PAID'
    record('Reading adds no request/audit action; nested returned mutations and later analysis/payment cannot rewrite original history',
           originalRecords=before_records, laterStatus='PARTIALLY_PAID', copiesDetached=True)

    lost = new_demo()
    aid, iid, queued = draft(lost, 'response-lost')
    actual_send = lost.mock.send_invoice
    effects = []
    def send_then_lose(*args, **kwargs):
        result = actual_send(*args, **kwargs)
        effects.append(detached(result.body))
        raise ConnectionError('Authored loss after the actual SandboxMock send')
    lost.mock.send_invoice = send_then_lose
    try:
        failed = call(lost, 'approve', action_id=aid)
    finally:
        lost.mock.send_invoice = actual_send
    assert failed['ok'] is False and failed['error'] == 'ConnectionError'
    assert len(effects) == 1 and lost.mock.invoices[iid]['status'] == 'SENT'
    failed_record = history(lost)[0]
    assert failed_record['id'] == aid and failed_record['status'] == 'FAILED'
    assert failed_record['result']['outcome'] == 'UNKNOWN'
    assert failed_record['payload'] == queued['payload']
    sends_before = detached(lost.mock.requests)
    duplicate = call(lost, 'approve', action_id=aid)
    assert duplicate['ok'] is False
    assert detached(lost.mock.requests) == sends_before and len(effects) == 1
    record('An actual mock send followed by a lost response remains FAILED/UNKNOWN and cannot be replayed by its consumed ID',
           record=failed_record, actualEffects=len(effects), explicitSecondApprovalAccepted=False)

    refused = new_demo()
    aid, iid, queued = draft(refused, 'known-refusal')
    # The actual mock provider has already sent this draft, independently of the agent's approval.
    refused.mock.send_invoice(iid, {'send_to_recipient': True})
    rejected_send = call(refused, 'approve', action_id=aid)
    assert rejected_send['ok'] is False and rejected_send['error'] == 'PayPalError'
    refusal_record = history(refused)[0]
    assert refusal_record['status'] == 'FAILED'
    assert refusal_record['result'].get('outcome') != 'UNKNOWN'
    assert refusal_record['payload'] == queued['payload']
    record('A native provider refusal is retained as its actual error body, distinct from unknown delivery',
           record=refusal_record, error=rejected_send['message'])

    invalidated = new_demo()
    aid, iid, _ = draft(invalidated, 'reminder-change')
    require_ok(call(invalidated, 'approve', action_id=aid))
    require_ok(call(invalidated, 'advance', day='2026-10-15'))
    chased = require_ok(call(invalidated, 'chase'))
    reminders = [p for p in chased['state']['pending'] if p['kind'] == 'send_reminder']
    assert len(reminders) == 1
    reminder = reminders[0]
    original_reminder = original(invalidated.agent.pending[reminder['id']])
    require_ok(call(invalidated, 'payment', invoice_id=iid, amount='1.10'))
    terminal = next(r for r in history(invalidated) if r['id'] == reminder['id'])
    assert terminal['status'] == 'REJECTED'
    assert terminal['result']['reason'].startswith('auto:')
    assert terminal['payload'] == original_reminder['payload']
    assert terminal['created_at'] == original_reminder['created_at']
    record('Later native payment invalidates a queued reminder without rewriting its original subject/note',
           record=terminal, originalProposal=original_reminder)

    long = new_demo()
    identities = []
    for index in range(26):
        aid, _, _ = draft(long, f'window-{index:02d}')
        identities.append(aid)
        require_ok(call(long, 'reject', action_id=aid))
    rows = history(long)
    assert len(long.snapshot()['audit']) == 18 and len(long.agent.audit) > 18
    assert [r['id'] for r in rows] == list(reversed(identities))
    assert all(r['status'] == 'REJECTED' for r in rows)
    preserved_last = detached(rows)
    require_ok(call(long, 'reset'))
    assert history(long) == [] and long.agent.pending == {}
    assert len(preserved_last) == 26
    record('All 26 retained originals outlive the 18-row audit window, while explicit reset clears the new session history',
           count=26, actionIDs=identities, oldestRecord=preserved_last[-1],
           resetMockRequests=len(long.mock.requests))
    assert not network_attempts
    report['passed'] = True
except Exception as exc:
    report['failure'] = {'type': type(exc).__name__, 'message': str(exc),
                         'traceback': traceback.format_exc()}
finally:
    report['sourceUnchanged'] = all(hashlib.sha256((source / p).read_bytes()).hexdigest() == pin['sha256']
                                    for p, pin in pins.items())
    report['harnessSHA256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (output / 'receipt.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'passed': report['passed'], 'checks': len(report['checks']),
                      'receipt': str(output / 'receipt.json'),
                      'failure': report.get('failure'), 'networkAttempts': network_attempts,
                      'sourceUnchanged': report['sourceUnchanged']}, ensure_ascii=False))
sys.exit(0 if report['passed'] else 1)
