import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import http from 'node:http';
import assert from 'node:assert/strict';
import {chromium} from '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';

const appRoot = path.resolve(process.argv[2] || 'candidate/web-demo');
const out = path.resolve(process.argv[3] || 'receiving/browser-candidate');
fs.mkdirSync(out, {recursive:true});
const dist = path.join(appRoot,'dist');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const blob = bytes => crypto.createHash('sha1').update(Buffer.from('blob '+bytes.length+'\0')).update(bytes).digest('hex');
const pins = root => {
  const result = {};
  const walk = at => { for (const item of fs.readdirSync(at,{withFileTypes:true})) {
    const absolute=path.join(at,item.name); if(item.isDirectory()) walk(absolute);
    else {const bytes=fs.readFileSync(absolute);result[path.relative(root,absolute)]={bytes:bytes.length,sha256:sha(bytes),gitBlob:blob(bytes)};}
  }};
  walk(root);return result;
};
const canonicalDecimalText=value=>{
 assert.equal(typeof value,'string');
 assert.match(value,/^-?(?:0|[1-9]\d*)(?:\.\d+)?$/);
 return value.includes('.')?value.replace(/0+$/,'').replace(/\.$/,''):value;
};
const before = pins(dist);

const sourceAdmission=JSON.parse(fs.readFileSync(path.resolve(appRoot,'../../successor-source-admission.json'),'utf8'));
const sourceGuard=()=>{
 for(const [name,pin] of Object.entries(sourceAdmission.materializedSource)){
  assert.equal(sha(fs.readFileSync(path.resolve(appRoot,'..',name))),pin.sha256,name);
 }
 return {files:Object.keys(sourceAdmission.materializedSource).length,allExact:true};
};

const lock=JSON.parse(fs.readFileSync(path.join(appRoot,'package-lock.json'),'utf8'));
const versions={};
for(const name of ['pyodide','typescript','vite','vitest']){
  const actual=JSON.parse(fs.readFileSync(path.join(appRoot,'node_modules',name,'package.json'),'utf8')).version;
  const expected=lock.packages['node_modules/'+name].version;
  assert.equal(actual,expected);versions[name]={actual,locked:expected};
}
const receipt={
 schema:'ledgerly.independent-successor-browser-completed-reviews.v1',
 candidate:'6cd400e1a0c4c9fd79016d57d5cf24d0b49f4906',
 tree:'4249cf3905d4ac26dc1124e599be835982f11eb2',
 appRoot, node:process.version, packageVersions:versions,
 harnessSHA256:sha(fs.readFileSync(new URL(import.meta.url))),
 instrumentation:'An observational subclass forwards each native Worker constructor and postMessage unchanged and copies actual replies. No worker, Python function, API response, or product state is substituted. No Worker fault is injected in this bounded successor continuation.',
 boundary:'Real compiled production app and self-hosted Pyodide running real Ledgerly/Agent/SandboxMock with fictional invoice data; loopback static delivery only. Explicit UI decisions affect only in-memory fictional sandbox state.',
 checks:[],requests:[],served:[],externalAttempts:[],pageErrors:[],consoleErrors:[],passed:false,
 distBefore:before, sourceBefore:sourceGuard(), scope:'Only new exact-value admission and canonical serialization through actual approved-review/payment integration. Prior keyboard, reset and unavailable groups are not repeated here.'
};
let browser, context, page;
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.py':'text/plain; charset=utf-8','.txt':'text/plain; charset=utf-8','.wasm':'application/wasm','.zip':'application/zip','.svg':'image/svg+xml'};
const server=http.createServer((req,res)=>{
 try {
  const u=new URL(req.url,'http://127.0.0.1');
  const relative=decodeURIComponent(u.pathname).replace(/^\/+/,'') || 'index.html';
  const file=path.resolve(dist,relative);
  if(!file.startsWith(dist+path.sep)||!['GET','HEAD'].includes(req.method)){res.writeHead(403);res.end();return;}
  if(!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404);res.end('Not found');receipt.served.push({method:req.method,path:relative,status:404});return;}
  const bytes=fs.readFileSync(file);
  receipt.served.push({method:req.method,path:relative,status:200,bytes:bytes.length,sha256:sha(bytes)});
  assert.equal(sha(bytes),before[relative].sha256,'served file must match frozen compiled bytes');
  res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','Content-Length':bytes.length,'Cache-Control':'no-store'});
  res.end(req.method==='HEAD'?undefined:bytes);
 } catch(e){receipt.serverError=String(e);res.writeHead(500);res.end('Receiver error');}
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const origin='http://127.0.0.1:'+server.address().port;
receipt.origin=origin;
const check=(name,details={})=>receipt.checks.push({name,passed:true,...details});
const lastState=async()=>page.evaluate(()=>[...window.__ledgerlyObserve.replies].reverse().find(x=>x.data?.state)?.data.state);
const counters=async()=>page.evaluate(()=>({posts:window.__ledgerlyObserve.requests.length,mock:Number(document.querySelector('#mock-requests').textContent),external:Number(document.querySelector('#external-calls').textContent)}));
const record= id=>page.locator('details.completed-review[data-review-id="'+id+'"]');
const outer= id=>record(id).locator(':scope > summary');
const nested= id=>record(id).locator('details.approval-preview > summary');
const focused=async(id,kind)=>page.evaluate(({id,kind})=>{
 const panel=document.querySelector('details.completed-review[data-review-id="'+id+'"]');
 const target=kind==='outer'?panel?.querySelector(':scope > summary'):panel?.querySelector('details.approval-preview > summary');
 return document.activeElement===target;
},{id,kind});
async function perform(action,activate){
 const count=await page.evaluate(()=>window.__ledgerlyObserve.requests.length);
 await activate();
 await page.waitForFunction(n=>window.__ledgerlyObserve.requests.length>n,count,{timeout:45000});
 const request=await page.evaluate(n=>window.__ledgerlyObserve.requests[n],count);
 assert.equal(request.action,action);
 await page.waitForFunction(id=>window.__ledgerlyObserve.replies.some(x=>x.id===id),request.id,{timeout:90000});
 const reply=await page.evaluate(id=>window.__ledgerlyObserve.replies.find(x=>x.id===id),request.id);
 assert.equal(reply.ok,true,JSON.stringify(reply)); assert.equal(reply.data?.ok,true,JSON.stringify(reply.data));
 await page.waitForFunction(()=>!document.querySelector('#analyze').disabled,{timeout:45000});
 assert.equal((await counters()).external,0);
 return reply.data;
}
async function activateThenFocus(selector,id,kind){
 await page.evaluate(({selector,id,kind})=>{
  document.querySelector(selector).click();
  const panel=document.querySelector('details.completed-review[data-review-id="'+id+'"]');
  (kind==='outer'?panel.querySelector(':scope > summary'):panel.querySelector('details.approval-preview > summary')).focus();
 },{selector,id,kind});
}
async function makeDraft(label,currency,keepFocus){
 const previous=new Set((await lastState()).pending.map(x=>x.id));
 const email='Independent receiving '+label+'. The structured corrections below are fictional and explicitly checked.';
 await page.locator('#job-email').fill(email);
 const analyzed=await perform('analyze',()=>keepFocus?activateThenFocus('#analyze',keepFocus,'nested'):page.locator('#analyze').click());
 if(keepFocus) assert(await focused(keepFocus,'nested'),'nested proposal focus survives actual analyze reply');
 await page.locator('#review-editor > summary').focus(); await page.keyboard.press('Enter');
 await page.locator('#review-client-name').fill('Málaga 日本語 '+label);
 await page.locator('#review-client-email').fill(label+'@receiver.example.test');
 await page.locator('#review-due-days').fill('2');
 await page.locator('#review-amount-paid').fill('0');
 while(await page.locator('[data-remove-line]').count()) await page.locator('[data-remove-line]').first().click();
 const lines=[
  {desc:'<spec> & "literal" '+label,qty:'2',price:'12.30',unit:'hours'},
  {desc:'Follow-up 日本語 '+label,qty:'1',price:'7.40',unit:''}
 ];
 for(let i=0;i<lines.length;i++){
  await page.locator('#review-add-line').click();
  await page.locator('#review-line-'+i+'-desc').fill(lines[i].desc);
  await page.locator('#review-line-'+i+'-qty').fill(lines[i].qty);
  await page.locator('#review-line-'+i+'-price').fill(lines[i].price);
  await page.locator('#review-line-'+i+'-currency').selectOption(currency);
  await page.locator('#review-line-'+i+'-unit').fill(lines[i].unit);
 }
 await page.locator('#review-confirm').check();
 const review=await perform('review',()=>page.locator('#review-check').click());
 assert.equal(review.result.valid,true);
 const drafted=await perform('draft',()=>page.locator('#draft').click());
 assert.equal(drafted.result.unauthorized_send_blocked,true);
 const added=drafted.state.pending.filter(x=>!previous.has(x.id));
 assert.equal(added.length,1); assert.equal(added[0].kind,'send_invoice');
 return {proposal:added[0],email,lines,analyzedSource:analyzed.result.source};
}
function originalFields(value){
 const result={...value};delete result.status;delete result.result;return result;
}
async function readRecord(id,expected){
 const panel=record(id);
 if((await panel.getAttribute('open'))===null) {await outer(id).focus();await page.keyboard.press('Enter');}
 assert.deepEqual(JSON.parse(await panel.locator('[data-review-result]').textContent()),expected.result);
 assert((await panel.textContent()).includes(expected.created_at));
 assert((await panel.textContent()).includes(expected.payload.invoice.items[0].name));
 assert.equal(await panel.locator('spec').count(),0);
 assert.equal(await panel.locator('button').count(),0);
}
try {
 browser=await chromium.launch({executablePath:'/workspace/scratch/3e50c5ad22c5/production/browser/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage'],downloadsPath:path.join(out,'downloads')});
 receipt.chromiumVersion=browser.version();
 context=await browser.newContext({viewport:{width:1280,height:900},serviceWorkers:'block'});
 await context.route('**/*',route=>{
  const url=new URL(route.request().url());
  receipt.requests.push({url:url.href,method:route.request().method(),type:route.request().resourceType()});
  if(url.origin===origin || ['blob:','data:','about:'].includes(url.protocol)) return route.continue();
  receipt.externalAttempts.push(url.href);return route.abort('blockedbyclient');
 });
 await context.addInitScript(()=>{
  const NativeWorker=window.Worker;
  window.__ledgerlyObserve={requests:[],replies:[],constructors:[],faults:[]};
  window.__ledgerlyNativeWorkers=[];
  window.Worker=class extends NativeWorker{
   constructor(url,options){
    super(url,options);
    window.__ledgerlyNativeWorkers.push(this);
    window.__ledgerlyObserve.constructors.push({url:String(url),options});
    this.addEventListener('message',event=>window.__ledgerlyObserve.replies.push(JSON.parse(JSON.stringify(event.data))));
   }
   postMessage(...args){
    window.__ledgerlyObserve.requests.push(JSON.parse(JSON.stringify(args[0])));
    return super.postMessage(...args);
   }
  };
 });
 page=await context.newPage();
 page.on('pageerror',error=>receipt.pageErrors.push(String(error)));
 page.on('console',msg=>{if(msg.type()==='error')receipt.consoleErrors.push(msg.text());});
 await page.goto(origin+'/',{waitUntil:'networkidle'});
 assert.match(await page.locator('#completed-reviews-note').textContent(),/Load the local engine/);
 const initial=await perform('init',()=>page.locator('#engine-start').click());
 assert.deepEqual(initial.state.completed_reviews,[]);
 assert.match(await page.locator('#engine-status').textContent(),/PYTHON READY/);
 check('Compiled app boots actual self-hosted Pyodide and a new empty native sandbox');

 const sourceEmail='Independent successor integration. Human-reviewed fictional invoice.';
 await page.locator('#job-email').fill(sourceEmail);
 await perform('analyze',()=>page.locator('#analyze').click());
 await page.locator('#review-editor > summary').click();
 await page.locator('#review-client-name').fill('Málaga 日本語 successor');
 await page.locator('#review-client-email').fill('successor@receiver.example.test');
 await page.locator('#review-due-days').fill('2');
 await page.locator('#review-amount-paid').fill('0');
 while(await page.locator('[data-remove-line]').count()) await page.locator('[data-remove-line]').first().click();
 for(const [i,row] of [
  {desc:'<spec> & "literal" successor',qty:'2.00000',price:'0.001',unit:'hours'},
  {desc:'Follow-up 日本語 successor',qty:'1',price:'7.40',unit:''}
 ].entries()){
  await page.locator('#review-add-line').click();
  await page.locator('#review-line-'+i+'-desc').fill(row.desc);
  await page.locator('#review-line-'+i+'-qty').fill(row.qty);
  await page.locator('#review-line-'+i+'-price').fill(row.price);
  await page.locator('#review-line-'+i+'-currency').selectOption('EUR');
  await page.locator('#review-line-'+i+'-unit').fill(row.unit);
 }
 await page.locator('#review-confirm').check();
 const invalid=await perform('review',()=>page.locator('#review-check').click());
 assert.equal(invalid.result.valid,false);
 assert(invalid.result.issues.some(x=>x.severity==='error'&&x.field.includes('unit_price')));
 assert.equal((await counters()).mock,0);
 assert.deepEqual(invalid.state.ledger,[]);assert.deepEqual(invalid.state.pending,[]);
 assert.equal(await page.locator('#draft').isDisabled(),true);
 check('Actual current Pyodide validation refuses fractional currency units and disables drafting before any mock invoice request',{issues:invalid.result.issues});
 await page.locator('#review-line-0-price').fill('12.30');
 await page.locator('#review-confirm').check();
 const valid=await perform('review',()=>page.locator('#review-check').click());
 assert.equal(valid.result.valid,true);
 const drafted=await perform('draft',()=>page.locator('#draft').click());
 assert.equal(drafted.result.unauthorized_send_blocked,true);
 assert.equal(drafted.state.pending.length,1);
 const proposal=drafted.state.pending[0];
 assert.deepEqual(proposal.payload.invoice.items.map(x=>x.quantity),['2','1']);
 assert.deepEqual(proposal.payload.invoice.items.map(x=>x.unit_amount.value),['12.30','7.40']);
 const approved=await perform('approve',()=>page.locator('[data-approve="'+proposal.id+'"]').click());
 const retained=approved.state.completed_reviews[0];
 assert.equal(retained.status,'APPROVED');
 assert.deepEqual(originalFields(retained),originalFields(proposal));
 await readRecord(proposal.id,retained);
 const saveButton=page.locator('[data-save-invoice-record="'+proposal.invoice_id+'"]');
 assert.equal(await saveButton.count(),1);assert.equal(await saveButton.isEnabled(),true);
 await page.locator('#payment-amount').fill('2.20');
 const paid=await perform('payment',()=>page.locator('[data-pay="'+proposal.invoice_id+'"]').click());
 assert.deepEqual(paid.state.completed_reviews,[retained]);
 const currentInvoice=paid.state.ledger.find(x=>x.invoice_id===proposal.invoice_id);
 assert.equal(currentInvoice.status,'PARTIALLY_PAID');
 assert.equal(canonicalDecimalText(currentInvoice.paid_amount),'2.2');assert.equal(canonicalDecimalText(currentInvoice.balance),'29.8');
 await readRecord(proposal.id,retained);
 assert.equal(await saveButton.count(),1);assert.equal(await saveButton.isEnabled(),true);
 check('Canonical queued quantity and original approved result remain exact after real payment while current save-record hooks stay available',{actionId:proposal.id,invoiceId:proposal.invoice_id,quantity:proposal.payload.invoice.items[0].quantity,paidAmount:currentInvoice.paid_amount,balance:currentInvoice.balance});
 receipt.finalCounters=await counters();
 assert.equal(receipt.externalAttempts.length,0);assert.equal(receipt.pageErrors.length,0);assert.equal(receipt.consoleErrors.length,0);assert.equal(receipt.serverError,undefined);
 receipt.passed=true;
} catch(error) {
 receipt.error={name:error.name,message:error.message,stack:error.stack};
 if(page) try {await page.screenshot({path:path.join(out,'failure.png'),fullPage:false});}catch{}
 process.exitCode=1;
} finally {
 if(page) try {receipt.workerObservation=await page.evaluate(()=>window.__ledgerlyObserve);}catch{}
 receipt.sourceAfter=sourceGuard();
 receipt.distAfter=pins(dist);
 receipt.distUnchanged=JSON.stringify(receipt.distAfter)===JSON.stringify(before);
 if(!receipt.distUnchanged){receipt.passed=false;process.exitCode=1;}
 await context?.close();await browser?.close();
 await new Promise(resolve=>server.close(resolve));
 const target=path.join(out,'receipt.json');
 fs.writeFileSync(target,JSON.stringify(receipt,null,2)+'\n');
 const bytes=fs.readFileSync(target);
 console.log(JSON.stringify({passed:receipt.passed,checks:receipt.checks,requests:receipt.requests.length,served:receipt.served.length,externalAttempts:receipt.externalAttempts,pageErrors:receipt.pageErrors,consoleErrors:receipt.consoleErrors,error:receipt.error,receipt:target,bytes:bytes.length,sha256:sha(bytes),distUnchanged:receipt.distUnchanged}));
}
