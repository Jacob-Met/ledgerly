"""Restore the exact selected source bodies used by this receiving packet."""
import hashlib,json,pathlib,tarfile
root=pathlib.Path(__file__).resolve().parents[1]
archive=root/'source-inputs/frozen-source-inputs.tar.gz'
custody=json.loads((root/'source-inputs/source-archive-custody.json').read_text())
assert hashlib.sha256(archive.read_bytes()).hexdigest()==custody['sha256']
with tarfile.open(archive,'r:gz') as tar:
    bodies={m.name:tar.extractfile(m).read() for m in tar.getmembers()}
admission=json.loads(bodies['native-source-admission.json'])
for row in admission['inputs']:
    data=bodies['input-blobs/'+row['sha']]
    assert len(data)==row['size'] and hashlib.sha256(data).hexdigest()==row['sha256']
    for label in row['labels']:
        p=root/label/row['path'];p.parent.mkdir(parents=True,exist_ok=True)
        if p.exists():assert p.read_bytes()==data,p
        else:p.write_bytes(data)
(root/'native-source-admission.json').write_bytes(bodies['native-source-admission.json'])
print(json.dumps({'restoredRolePaths':sum(len(r['labels']) for r in admission['inputs']),'allSourceBodiesExact':True}))
