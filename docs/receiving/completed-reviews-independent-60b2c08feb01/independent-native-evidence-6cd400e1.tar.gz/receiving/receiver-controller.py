import sys,os,json,pathlib,tempfile,shutil,hashlib,subprocess,time,termios,tarfile,gzip
shared=pathlib.Path('/dev/shm/estate-60b2c08feb01-ledgerly-history-independent')
runtime=pathlib.Path(tempfile.mkdtemp(prefix='estate-60b2c08feb01-ledgerly-recovery-',dir='/dev'))
archive=shared/'frozen-source-inputs.tar.gz'
custody=json.loads((shared/'source-archive-custody.json').read_text())
assert hashlib.sha256(archive.read_bytes()).hexdigest()==custody['sha256']
with tarfile.open(archive,'r:gz') as tar:
    stored={m.name:tar.extractfile(m).read() for m in tar.getmembers()}
admission=json.loads(stored['native-source-admission.json'])
pins=admission['inputs']
for row in pins:
    data=stored['input-blobs/'+row['sha']]
    assert hashlib.sha256(data).hexdigest()==row['sha256']
    for label in row['labels']:
        p=runtime/label/row['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);p.chmod(0o444)
(runtime/'native-source-admission.json').write_bytes(stored['native-source-admission.json'])
for name in ['receiving','logs','tmp']:(runtime/name).mkdir()
checkpoints=shared/'recovery-checkpoints';checkpoints.mkdir(exist_ok=True)
cache=shared/'receiver-source-cache';cache.mkdir(exist_ok=True)
os.environ['TMPDIR']=str(runtime/'tmp')
os.environ['PYTHONDONTWRITEBYTECODE']='1'
os.environ.pop('LEDGERLY_ALLOW_NETWORK',None)
if sys.stdin.isatty():
    attr=termios.tcgetattr(sys.stdin.fileno());attr[3]&=~(termios.ECHO|termios.ICANON);termios.tcsetattr(sys.stdin.fileno(),termios.TCSANOW,attr)
def under(relative):
    p=pathlib.Path(relative)
    if p.is_absolute() or '..' in p.parts:raise ValueError('Relative runtime paths only')
    return runtime/p
def check():
    for row in pins:
        for label in row['labels']:
            assert hashlib.sha256((runtime/label/row['path']).read_bytes()).hexdigest()==row['sha256'],(label,row['path'])
    return {'sourceFiles':sum(len(r['labels']) for r in pins),'allExact':True}
def checkpoint(label,names):
    target=checkpoints/(label+'.tar.gz');assert not target.exists()
    temporary=checkpoints/(label+'.pending')
    files={}
    for name in names:
        p=under(name)
        if p.is_dir():
            for item in p.rglob('*'):
                if item.is_file():files[str(item.relative_to(runtime))]=item
        elif p.is_file():files[str(p.relative_to(runtime))]=p
        else:raise ValueError('Checkpoint input missing: '+name)
    with tarfile.open(temporary,'w:gz',compresslevel=9,dereference=True) as tar:
        for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
    members=[]
    with tarfile.open(temporary,'r:gz') as tar:
        for member in tar.getmembers():
            body=tar.extractfile(member).read();p=files[member.name]
            assert body==p.read_bytes()
            members.append({'path':member.name,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()})
    os.replace(temporary,target);target.chmod(0o444)
    receipt={'file':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'allMembersReadBack':True,'members':members}
    (checkpoints/(label+'.manifest.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    return {k:v for k,v in receipt.items() if k!='members'}|{'members':len(members)}
print(json.dumps({'ready':True,'runtime':str(runtime),'python':sys.version,'node':subprocess.check_output(['node','--version']).decode().strip(),'source':check(),'immediateSharedCheckpoints':str(checkpoints)}),flush=True)
for line in sys.stdin:
    try:
        request=json.loads(line);action=request['action']
        if action=='write':
            saved=[]
            for name,content in request['files'].items():
                if not name.startswith('receiving/'):raise ValueError('Only receiver files may be authored')
                p=under(name);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content)
                data=p.read_bytes();digest=hashlib.sha256(data).hexdigest()
                gz=cache/(digest+'.gz')
                if not gz.exists():gz.write_bytes(gzip.compress(data,compresslevel=9,mtime=0));gz.chmod(0o444)
                assert gzip.decompress(gz.read_bytes())==data
                record={'path':name,'bytes':len(data),'sha256':digest,'sharedBody':str(gz)}
                with (shared/'receiver-source-cache.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
                saved.append(record)
            print(json.dumps({'written':saved}),flush=True)
        elif action=='run':
            label=request['label'];assert label.replace('-','').replace('_','').isalnum()
            started=time.monotonic()
            try:
                result=subprocess.run(request['args'],cwd=under(request.get('cwd','.')),capture_output=True,timeout=request.get('timeout',120),env=os.environ.copy())
                out,err,code=result.stdout,result.stderr,result.returncode
            except subprocess.TimeoutExpired as exc:
                out,err,code=exc.stdout or b'',exc.stderr or b'',124
            (runtime/'logs'/f'{label}.stdout').write_bytes(out);(runtime/'logs'/f'{label}.stderr').write_bytes(err)
            receipt={'label':label,'args':request['args'],'cwd':request.get('cwd','.'),'exitCode':code,'duration':time.monotonic()-started,'stdoutBytes':len(out),'stderrBytes':len(err),'stdoutSHA256':hashlib.sha256(out).hexdigest(),'stderrSHA256':hashlib.sha256(err).hexdigest(),'source':check()}
            (runtime/'logs'/f'{label}.command.json').write_text(json.dumps(receipt,indent=2)+'\n')
            saved=checkpoint(label,[f'logs/{label}.stdout',f'logs/{label}.stderr',f'logs/{label}.command.json']+request.get('checkpoint',[]))
            print(json.dumps({**receipt,'sharedCheckpoint':saved,'stdoutTail':out.decode(errors='replace')[-request.get('tail',2000):],'stderrTail':err.decode(errors='replace')[-1000:]}),flush=True)
        elif action=='read':
            p=under(request['path'])
            if request.get('json'):print(json.dumps({'path':request['path'],'data':json.loads(p.read_text())}),flush=True)
            else:print(json.dumps({'path':request['path'],'content':p.read_text()[:request.get('limit',12000)]}),flush=True)
        elif action=='check':
            print(json.dumps({'source':check(),'runtime':str(runtime)}),flush=True)
        elif action=='exit':
            print(json.dumps({'closing':True,'source':check()}),flush=True)
            shutil.rmtree(runtime);break
        else:raise ValueError('Unknown receiver-controller operation')
    except Exception as exc:
        print(json.dumps({'controllerError':type(exc).__name__,'message':str(exc)}),flush=True)
