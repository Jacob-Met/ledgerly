"""Author receiving of unknown provider status before invoice-send approval."""
from copy import deepcopy
from datetime import date
import hashlib
import os
from pathlib import Path
import sys
import unittest

ROOT = Path(os.environ["LEDGERLY_SOURCE_ROOT"]).resolve()
sys.path.insert(0, str(ROOT))
from ledgerly.agent import Agent
from ledgerly.paypal import SandboxMock

class SendStatusReceiving(unittest.TestCase):
    def draft(self):
        mock = SandboxMock()
        agent = Agent(mock, {"name": "Review Fixture", "email_address": "review@fixture.example"},
                      today=lambda: date(2026, 10, 8))
        created = agent.tool_create_invoice((ROOT / "fixtures/01_simple_usd_hourly.txt").read_text())
        self.assertTrue(created["ok"])
        item = created["invoices"][0]
        return agent, mock, item["invoice_id"], item["approval_id"]

    def test_unknown_status_is_a_failed_read_with_explicit_same_review_retry(self):
        for status in ("UNAVAILABLE", " ", "DRAFT "):
            with self.subTest(status=status):
                agent, mock, invoice_id, action_id = self.draft()
                original = deepcopy(agent.pending[action_id].to_dict())
                offset = len(mock.requests)
                original_read = mock.get_invoice
                def reported(inv_id):
                    response = original_read(inv_id)
                    response.body["status"] = status
                    return response
                mock.get_invoice = reported
                with self.assertRaises(ValueError):
                    agent.approve(action_id)
                self.assertEqual(agent.pending[action_id].to_dict(), original)
                self.assertEqual([request for request in mock.requests[offset:] if request[0] == "POST"], [])
                self.assertEqual(agent.client._permits, set())
                self.assertEqual(mock.invoices[invoice_id]["status"], "DRAFT")
                mock.get_invoice = original_read
                agent.approve(action_id)
                self.assertEqual(agent.pending[action_id].status, "APPROVED")
                self.assertEqual([r[:2] for r in mock.requests[offset:] if r[0] == "POST"],
                                 [("POST", f"/v2/invoicing/invoices/{invoice_id}/send")])

    def test_known_non_draft_remains_a_consumed_review_without_post(self):
        agent, mock, invoice_id, action_id = self.draft()
        offset = len(mock.requests)
        mock.invoices[invoice_id]["status"] = "SENT"
        original = deepcopy(agent.pending[action_id].payload)
        with self.assertRaises(ValueError):
            agent.approve(action_id)
        self.assertEqual(agent.pending[action_id].status, "REJECTED")
        self.assertEqual(agent.pending[action_id].payload, original)
        self.assertEqual([r for r in mock.requests[offset:] if r[0] == "POST"], [])
        self.assertEqual(agent.client._permits, set())

if __name__ == "__main__":
    print("agent_sha256=" + hashlib.sha256((ROOT / "ledgerly/agent.py").read_bytes()).hexdigest())
    unittest.main(verbosity=2)
